# Richard Henderson
 

 ---
**Contact URL:**https://twitter.com/richsentme
![[Richard Henderson_0.png]]

 ---
Richard Henderson is a writer, researcher, and ham radio/electronics nerd who has worked in infosec and technology for almost two decades. Richard has taught multiple times at DEF CON and leads the annual DEF CON Ham Radio Fox Hunt Contest. Richard is currently co-authoring a book on cybersecurity for ICS/Scada systems.