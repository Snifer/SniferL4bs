# Jenko Hwong
 Netskope Threat Research team

 ---
**Contact URL:**https://twitter.com/jenkohwong
![[Jenko Hwong_0.png]]

 ---
Jenko Hwong is on the Netskope Threat Research team, focusing on cloud threats/vectors. He's spent time in engineering and product roles at various security startups in vulnerability scanning, AV/AS, pen-testing/exploits, L3/4 appliances, threat intel, and windows security.