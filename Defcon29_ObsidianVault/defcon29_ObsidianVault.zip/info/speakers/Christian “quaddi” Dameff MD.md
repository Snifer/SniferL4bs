# Christian “quaddi” Dameff MD
Physician & Medical Director of Cyber Security at The University of California San Diego

 ---
**Contact URL:**https://twitter.com/CDameffMD
![[Christian “quaddi” Dameff MD_0.png]]

 ---
Christian (quaddi) Dameff MD is an Assistant Professor of Emergency Medicine, Biomedical Informatics, and Computer Science (Affiliate) at the University of California San Diego. He is also a hacker, former open capture the flag champion, and prior DEF CON/RSA/Blackhat/HIMSS speaker. Published works include topics such as therapeutic hypothermia after cardiac arrest, novel drug targets for myocardial infarction patients, and other Emergency Medicine related works with an emphasis on CPR optimization. Published security research topics including hacking critical healthcare infrastructure, medical devices and the effects of malware on patient care. This is his seventeenth DEF CON.