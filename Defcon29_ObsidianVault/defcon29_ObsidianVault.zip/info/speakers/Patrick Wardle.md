# Patrick Wardle
 Founder, Objective-See


 ---
**Contact URL:**https://twitter.com/patrickwardle
![[Patrick Wardle_0.png]]
**Contact URL:**https://objective-see.com/
![[Patrick Wardle_1.png]]

 ---
Patrick Wardle is the founder of Objective-See. Having worked at NASA and the NSA, as well as presenting at countless security conferences, he is intimately familiar with aliens, spies, and talking nerdy. Patrick is passionate about all things related to macOS security and thus spends his days finding Apple 0days, analyzing macOS malware, and writing free open-source security tools to protect Mac users.