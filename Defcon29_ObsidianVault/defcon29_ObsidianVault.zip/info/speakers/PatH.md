# PatH
 Security Researcher

 ---
**Contact URL:**https://twitter.com/pathtofile
![[PatH_0.png]]
**Contact URL:**https://path.tofile.dev/
![[PatH_1.png]]

 ---
Pat is a loving partner, a comedian to his daughter, and a dedicated ball retriever to his dog.