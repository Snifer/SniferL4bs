# Chad Seaman
 Lead & Senior Engineer @ Akamai SIRT

 ---
**Contact URL:**https://www.linkedin.com/in/that-chad-seaman/

 ---
Chad is the SIRT team lead @ Akamai Technologies. He spends his time being an internet dumpster diver and emerging threats researcher focusing on DDoS, malware, botnets, and digital hooliganism in general.