# Jeff “r3plicant” Tully MD
Anesthesiologist at The University of California San Diego

 ---
**Contact URL:**https://twitter.com/JeffTullyMD
![[Jeff “r3plicant” Tully MD_0.png]]

 ---
Jeff (r3plicant) Tully is an anesthesiologist, pediatrician and security researcher with an interest in understanding the ever-growing intersections between healthcare and technology.