# Mickey Shkatov
 Hacker

 ---
**Contact URL:**https://twitter.com/HackingThings
![[Mickey Shkatov_0.png]]

 ---
Mickey has been doing security research for almost a decade, one of specialties is simplifying complex concepts and finding security flaws in unlikely places. He has seen some crazy things and lived to tell about them at security conferences all over the world, his past talks range from web pentesting to black badges and from hacking cars to BIOS firmware.