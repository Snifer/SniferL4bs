# Brian Hong
 Security Consultant, NCC Group 

 ---

 ---
Brian Hong is a security consultant at NCC Group, a global information assurance specialist providing organizations with expert security consulting services. He specializes in hardware penetration testing, reverse engineering, and has performed security research related to embedded systems, firmware analysis, web application penetration testing, and Android security and malware analysis. Brian has a B. Eng. in Electrical Engineering and Computer Science from The Cooper Union.