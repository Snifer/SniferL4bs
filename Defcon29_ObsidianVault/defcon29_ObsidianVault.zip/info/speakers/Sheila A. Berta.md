# Sheila A. Berta
 Head of Research at Dreamlab Technologies

 ---
**Contact URL:**https://twitter.com/UnaPibaGeek
![[Sheila A. Berta_0.png]]

 ---
Sheila A. Berta is an offensive security specialist who started at 12 years-old by learning on her own. At the age of 15, she wrote her first book about Web Hacking, published in several countries. Over the years, Sheila has discovered vulnerabilities in popular web applications and software, as well as given courses at universities and private institutes in Argentina. She specializes in offensive techniques, reverse engineering, and exploit writing and is also a developer in ASM (MCU and MPU x86/x64), C/C++, Python and Go. The last years she focused on Cloud Native and Big Data security. As an international speaker, she has spoken at important security conferences such as Black Hat Briefings, DEF CON, HITB, Ekoparty, IEEE ArgenCon and others. Sheila currently works as Head of Research at Dreamlab Technologies.