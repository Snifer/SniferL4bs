# Selmon Yang
 Staff Engineer at TXOne Networks

 ---

 ---
Selmon Yang is a Staff Engineer at TXOne Networks. He is responsible for parsing IT/OT Protocol, linux kernel programming, and honeypot development and adjustment. Selmon also spoke at ICS Cyber Security Conference Asia, HITCON, SecTor and HITB.