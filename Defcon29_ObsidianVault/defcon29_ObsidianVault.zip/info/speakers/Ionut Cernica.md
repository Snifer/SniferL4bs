# Ionut Cernica
 PHD Student @Department of Computer Science, Faculty of Automatic Control and Computer Science, University Politehnica of Bucharest

 ---
**Contact URL:**https://twitter.com/CernicaIonut
![[Ionut Cernica_0.png]]

 ---
Ionut Cernica started his security career with the bug bounty program from Facebook. His passion for security led him to get involved in dozens of such programs and he found problems in very large companies such as Google, Microsoft, Yahoo, AT&T, eBay, VMware. He has also been testing web application security for 9 years and has had a large number of projects on the penetration testing side.