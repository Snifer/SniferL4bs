# Michael Whiteley
 MKFactor.com

 ---
**Contact URL:**https://twitter.com/compukidmike
![[Michael Whiteley_0.png]]

 ---
Michael is a husband, father, and electronics geek. He doesn't like long walks on the beach, but prefers to be indoors with a fast internet connection.