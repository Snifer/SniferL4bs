# Adam 'pi3' Zabrocki
 Principal System Software Engineer (Offensive Security) at NVIDIA

 ---
**Contact URL:**https://twitter.com/Adam_pi3
![[Adam 'pi3' Zabrocki_0.png]]
**Contact URL:**http://pi3.com.pl
![[Adam 'pi3' Zabrocki_1.png]]

 ---
Adam 'pi3' Zabrocki is a computer security researcher, pentester and bughunter, currently working as a Principal Offensive Security Researcher at NVIDIA. He is a creator and a developer of Linux Kernel Runtime Guard (LKRG) - his moonlight project defended by Openwall. Among others, he used to work in Microsoft, European Organization for Nuclear Research (CERN), HISPASEC Sistemas (known from the virustotal.com project), Wroclaw Center for Networking and Supercomputing, Cigital. The main area of his research interest is a low-level security (CPU architecture, uCode, FW, hypervisor, kernel, OS).