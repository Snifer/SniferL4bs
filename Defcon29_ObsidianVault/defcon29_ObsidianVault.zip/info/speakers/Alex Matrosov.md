# Alex Matrosov
 

 ---
**Contact URL:**https://twitter.com/matrosov
![[Alex Matrosov_0.png]]
**Contact URL:**https://medium.com/firmware-threat-hunting
![[Alex Matrosov_1.png]]

 ---
Alex Matrosov is a well-recognized offensive security researcher. He has more than two decades of experience with reverse engineering, advanced malware analysis, firmware security, and exploitation techniques. Alex served as Chief Offensive Security Researcher at Nvidia, Intel Security Center of Excellence (SeCoE), spent more than six years in the Intel Advanced Threat Research team, and was Senior Security Researcher at ESET. Alex has authored and co-authored numerous research papers, and is a frequent speaker at security conferences, including REcon, Zeronigths, Black Hat, DEF CON, and others. Additionally, he is awarded by Hex-Rays for open-source plugin efiXplorer and HexRaysCodeXplorer which has been developed and supported since 2013 by REhint's team.