# Ami Luttwak
 CTO, Wiz

 ---
**Contact URL:**https://twitter.com/amiluttwak
![[Ami Luttwak_0.png]]

 ---
Ami Luttwak is a serial entrepreneur, an experienced cyber security CTO and a hacker by heart. Mainly interested in cloud security and cloud exploits, understanding how the cloud is built to uncover its weaknesses. Currently CTO of Wiz, the fastest growing unicorn in cloud security, prior to that led research as CTO of Microsoft cloud security and prior to that founded Adallom, a pioneering cloud security startup acquired by Microsoft in 2015.