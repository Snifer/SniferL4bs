# Jesse "Agent X" Krembs
 

 ---
**Contact URL:**https://twitter.com/
![[Jesse "Agent X" Krembs_0.png]]

 ---
Jesse Krembs is a long term Def Con goon and now a staff information security analyst at The New York Times. He provides security support to journalists, and staff globally. He’s had a variety of jobs over his lifetime, working as a bike messenger, a caterer, a webmaster for a brewery, a wireless engineer, and doing even security work for the phone company. He leads the Def Con 4 X 5K, and climbs rocks for fun.