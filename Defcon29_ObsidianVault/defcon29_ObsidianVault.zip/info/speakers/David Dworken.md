# David Dworken
 Security Engineer, Google

 ---
**Contact URL:**https://twitter.com/ddworken
![[David Dworken_0.png]]
**Contact URL:**http://daviddworken.com
![[David Dworken_1.png]]

 ---
David is a bug bounty hunter turned software engineer turned security engineer. He started in security in high school hacking on bug bounties and then spent four years learning how to be an effective software engineer. He's worked on five different product security teams ranging from startups to large corporations.  He previously published a research paper on tracking malicious proxies in ACSAC. Currently, he works as a security engineer at Google working on deploying an alphabet soup of security headers across hundreds of services.