# Nick Draffen
 

 ---
**Contact URL:**https://twitter.com/tcprst 
![[Nick Draffen_0.png]]

 ---
Nick Draffen sometimes gives off a mad scientist vibe, an engineer who dives deep into technology, namely in the area where the physical and digital world meet. By day a security engineer/architect working to secure lab instruments and everything around them, and by night building/breaking things in his lab.