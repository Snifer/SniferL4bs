# jiska
 TU Darmstadt, SEEMOO

 ---
**Contact URL:**https://twitter.com/naehrdine
![[jiska_0.png]]

 ---
Jiska breaks things.