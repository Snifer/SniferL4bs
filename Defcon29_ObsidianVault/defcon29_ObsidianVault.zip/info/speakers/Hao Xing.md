# Hao Xing
 Tencent Security Xuanwu Lab

 ---
**Contact URL:**https://twitter.com/RonnyX2017
![[Hao Xing_0.png]]

 ---
Hao Xing is a Security researcher from Tencent Security Xuanwu Lab. He made some presentations at Chaos Communication Congress and BlackHat Asia. His research foucs on Web security, Andoird security and Red Team. He reported lots of vulnerabilities for many internet giants such as Google, Microsoft, Alibaba etc.