# Chuck McAuley
 Principal security researcher (ATIRC), at Keysight Technologies

 ---
**Contact URL:**https://twitter.com/nobletrout
![[Chuck McAuley_0.png]]

 ---
Chuck McAuley is a principal security researcher with the Application & Threat Intelligence Research Center (ATIRC) at Keysight Technologies. Chuck has a variety of interests that include 5G and LTE packet core vulnerabilities, reverse engineering botnets, finding novel forms of denial of service, and researching weird esoteric protocols for weaknesses and vulnerabilities