# Eugene Lim
 Cybersecurity Specialist, Government Technology Agency of Singapore

 ---
**Contact URL:**https://twitter.com/spaceraccoonsec
![[Eugene Lim_0.png]]
**Contact URL:**https://www.linkedin.com/in/limzhiweieugene/

 ---
Eugene Lim, also known as spaceraccoon, is a security researcher and white hat hacker. He regularly participates in live-hacking events and was awarded the Most Valuable Hacker title in the h1-213 Live-Hacking Event by Hackerone. Besides white hat hacking, he enjoys building security tools, including a malicious npm package scanner and an open-source intelligence social engineering honeypot that were presented at Black Hat Asia Arsenal 2019 and Black Hat USA Arsenal 2020. His writeups on https://spaceraccoon.dev are regularly cited by other white hat hackers.