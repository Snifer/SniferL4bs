# Cory Doctorow
 Author, journalist, activist.

 ---
**Contact URL:**https://twitter.com/doctorow
![[Cory Doctorow_0.png]]

 ---
Cory Doctorow (craphound.com) is a science fiction novelist, journalist and technology activist. He is a contributor to many magazines, websites and newspapers. He is a special consultant to the Electronic Frontier Foundation (eff.org), a non-profit civil liberties group that defends freedom in technology law, policy, standards and treaties. He holds an honorary doctorate in computer science from the Open University (UK), where he is a Visiting Professor; he is also a MIT Media Lab Research Affiliate and a Visiting Professor of Practice at the University of North Carolina’s School of Library and Information Science. In 2007, he served as the Fulbright Chair at the Annenberg Center for Public Diplomacy at the University of Southern California.