# Yuhao Weng
 Security Researcher of Sangfor

 ---
**Contact URL:**https://twitter.com/ cjm00nw
![[Yuhao Weng_0.png]]

 ---
Yuhao Weng(@cjm00nw) is an security researcher of Sangfor and a ctf player of Kap0k. He has been studying the web for three years and found a lot bugs in Sharepoint, Exchange and so on. Now he is focused on .NET security.