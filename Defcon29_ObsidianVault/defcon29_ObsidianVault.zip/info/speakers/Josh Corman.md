# Josh Corman
Chief Strategist for CISA, Founder of I am The Cavalry

 ---
**Contact URL:**https://twitter.com/joshcorman
![[Josh Corman_0.png]]

 ---
Joshua Corman is a Founder of I am The Cavalry (dot org), and serves as Chief Strategist for CISA regarding COVID, healthcare, and public safety. He previously served as CSO for PTC, Director of the Cyber Statecraft Initiative for the Atlantic Council, CTO for Sonatype, and other senior roles. He co-founded RuggedSoftware and IamTheCavalry to encourage new security approaches in response to the world’s increasing dependence on digital infrastructure. His unique approach to security in the context of human factors, adversary motivations, and social impact has helped position him as one of the most trusted names in security. He also serves as an Adjunct Faculty for Carnegie Mellon’s Heinz College, and was a member of the Congressional Task Force for Healthcare Industry Cybersecurity.NOTE: My CISA Emergency CARES Act Service may extend/change after July 15.