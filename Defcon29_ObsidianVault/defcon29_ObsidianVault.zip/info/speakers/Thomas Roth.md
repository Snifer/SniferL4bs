# Thomas Roth
 Hacker

 ---
**Contact URL:**https://twitter.com/ghidraninja
![[Thomas Roth_0.png]]
**Contact URL:**https://youtube.com/stacksmashing
![[Thomas Roth_1.png]]

 ---
Thomas Roth, also known as stacksmashing, is a security researcher from Germany
with a focus on embedded devices: From hacking payment terminals, crypto
wallets, secure processor, the Nintendo Game & Watch, up to Apple’s AirTag he
loves to explore embedded & IoT security. On how YouTube channel “stacksmashing”
he attempts to make reverse-engineering & hardware hacking more accessible.