# Rex Guo
 Head of Research, Confluera

 ---
**Contact URL:**https://twitter.com/Xiaofei_REX
![[Rex Guo_0.png]]
**Contact URL:**https://www.linkedin.com/in/xiaofeiguo/

 ---
Rex Guo works as Head of Research at Confluera where he leads the security research and development of the cloud XDR product which includes the real-time threat storyboarding capabilities (a.k.a. attack narrative). Before joining Confluera, he was an engineering manager at Cisco Tetration where his team bootstrapped the server EDR product deployed on millions of cloud endpoints. Before that, Rex worked at both Intel Security and Qualcomm. In these positions, he has worked on application security, infrastructure security, malware analysis, and mobile/ IoT platform security. He has presented at Blackhat multiple times. He has 30+ patents and publications. He received a PhD from New York University.