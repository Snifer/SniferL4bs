# Jeff Dileo
 Technical Director, NCC Group


 ---
**Contact URL:**https://twitter.com/chaosdatumz
![[Jeff Dileo_0.png]]

 ---
Jeff Dileo (chaosdata) is a security consultant by day, and sometimes by night. He hacks on embedded systems, mobile apps and devices, web apps, and complicated things that don't have names. He likes candy and arguing about text editors and window managers he doesn't actually use.