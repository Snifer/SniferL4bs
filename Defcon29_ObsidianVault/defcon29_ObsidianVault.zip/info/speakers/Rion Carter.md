# Rion Carter
 

 ---
**Contact URL:**https://twitter.com/7thzero.com
![[Rion Carter_0.png]]

 ---
Rion likes to solve interesting problems- the more esoteric and niche the better! He has varied interests ranging from software development and reverse-engineering to baking and recipe hacking. Rion currently works in DevSecOps where he and his colleagues wonder how they'll be rebranded next (DevSecBizFinOps?). Rumor has it that he bakes a mean batch of fudge brownies.