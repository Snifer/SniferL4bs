# Chuanda Ding
 Senior Researcher, Tencent Security Xuanwu Lab

 ---
**Contact URL:**https://twitter.com/FlowerCode_
![[Chuanda Ding_0.png]]

 ---
Chuanda Ding is a senior security researcher on Windows platform security. He leads EcoSec team at Tencent Security Xuanwu Lab. He was a speaker at Black Hat Europe 2018, DEF CON China 2018, CanSecWest 2017, CanSecWest 2016, and QCon Beijing 2016.