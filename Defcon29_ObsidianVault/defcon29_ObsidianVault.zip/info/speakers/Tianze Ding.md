# Tianze Ding
 Senior security researcher, Tencent Security Xuanwu Lab

 ---
**Contact URL:**https://twitter.com/D1iv3
![[Tianze Ding_0.png]]

 ---
Tianze Ding  is a senior security researcher at Tencent Security Xuanwu Lab. His research focuses on web security, active directory security and red teaming. He reported some vulnerabilities to Microsoft, Apple, Google, etc. He has spoken at BlackHat Asia.