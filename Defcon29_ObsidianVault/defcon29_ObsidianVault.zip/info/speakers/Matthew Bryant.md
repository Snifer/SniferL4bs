# Matthew Bryant
 Red Team @ Snapchat

 ---
**Contact URL:**https://twitter.com/IAmMandatory
![[Matthew Bryant_0.png]]
**Contact URL:** https://thehackerblog.com
![[Matthew Bryant_1.png]]

 ---
mandatory (Mathew Bryant) is a passionate hacker currently leading the red team effort at Snapchat. In his personal time he’s published a variety of tools such as XSS Hunter, CursedChrome, and tarnish. His security research has been recognized in publications such as Forbes, The Washington Post, CBS News, Techcrunch, and The Huffington Post. He has previously presented at Blackhat, RSA, Kiwicon, Derbycon, and Grrcon. Previous gigs include Google, Uber, and Bishop Fox.