# Alexander Heinrich
 TU Darmstadt, SEEMOO

 ---
**Contact URL:**https://twitter.com/Sn0wfreeze
![[Alexander Heinrich_0.png]]

 ---
Alexander is a security researcher at the Secure Mobile Networking Lab at the Technical University of Darmstadt. Before he joined the university as a researcher he gained a lot of experiences an an app developer on Apple operating systems starting with iOS 5. This deep understanding of the systems naturally resulted in a focus on those systems in his security research. He joined the Secure Mobile Networking Lab 2020 as a PhD student right after his Master Thesis on the security of  Apple’s Handoff and Universal Clipboard features. After working with a team of skilled researchers on AirDrop and Apple’s Find My network his focus now shifted to the security and privacy of ultra-wideband  and Apple U1 chip.