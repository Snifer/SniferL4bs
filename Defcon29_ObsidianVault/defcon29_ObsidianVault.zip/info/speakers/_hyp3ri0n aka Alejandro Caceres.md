# _hyp3ri0n aka Alejandro Caceres
 Director of Computer Network Exploitation at QOMPLX, former owner of Hyperion Gray

 ---

 ---
Bio coming soon!