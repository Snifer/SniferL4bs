# Vivek Nair
Ph.D. Student, EECS department, UC Berkeley

 ---

 ---
Vivek Nair is a Ph.D. student studying applied cryptography in the EECS department at UC Berkeley. He was the youngest-ever recipient of Bachelor’s and Master’s degrees in Computer Science at the University of Illinois at the ages of 18 and 19 respectively. He is also a National Science Foundation CyberCorps Scholar and a National Physical Science Consortium Fellow.