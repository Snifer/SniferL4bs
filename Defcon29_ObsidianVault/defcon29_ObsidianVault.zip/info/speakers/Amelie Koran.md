# Amelie Koran
Senior Technology Advocate, Splunk

 ---

 ---
