# Eran Segal
 Security Researcher @ SafeBreach Labs

 ---

 ---
Eran Segal is a security researcher, having 7+ years experience in cyber security research. He is working on security research projects in SafeBreach Labs in the last 2 years after serving in various sec positions at the IDF.