# Zhipeng Huo
 Senior Researcher, Tencent Security Xuanwu Lab

 ---
**Contact URL:**https://twitter.com/R3dF09
![[Zhipeng Huo_0.png]]

 ---
Zhipeng Huo is a senior security researcher on macOS and Windows platform security at Tencent Security Xuanwu Lab. He was a speaker at Black Hat Europe 2018 and DEF CON 28.