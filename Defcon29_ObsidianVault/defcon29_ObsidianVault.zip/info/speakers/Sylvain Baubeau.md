# Sylvain Baubeau
 Staff Engineer at Datadog

 ---

 ---
Sylvain Baubeau is a staff software engineer, mostly working on Linux, cloud and infrastructure technologies. In his spare time, he likes to play drums, reverse engineer old games and build arcades.