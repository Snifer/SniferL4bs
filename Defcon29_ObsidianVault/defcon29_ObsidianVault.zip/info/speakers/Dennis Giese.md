# Dennis Giese
 Hacker

 ---
**Contact URL:**https://twitter.com/dgi_DE
![[Dennis Giese_0.png]]
**Contact URL:**https://dontvacuum.me
![[Dennis Giese_1.png]]

 ---
Dennis is a PhD student and a cybersecurity researcher at Northeastern University. He was a member of one european ISP's CERT for several years.