# Babak Javadi
 Co-Founder, Red Team Alliance 

 ---
**Contact URL:**https://twitter.com/babakjavadi 
![[Babak Javadi_0.png]]

 ---
Babak Javadi is the Founder of The CORE Group and Co-Founder of the Red Team Alliance. In 2006 he co-founded of The Open Organisation of Lockpickers, serving as Director for 13 years. As a professional red teamer with over a decade of field experience, Babak’s expertise includes disciplines from high-security mechanical cylinders to alarms and physical access controls.