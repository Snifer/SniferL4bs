# Sach
 Hacker

 ---
**Contact URL:**https://twitter.com/0xkayn
![[Sach_0.png]]

 ---
Sach is a self taught developer, an aspiring pentester, and a drone enthusiast.
In his spare time he enjoys playing chess, reading Sci-Fi novels, learning about cryptocurrencies, and flying drones.