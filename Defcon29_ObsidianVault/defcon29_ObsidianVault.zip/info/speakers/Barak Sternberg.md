# Barak Sternberg
 Senior Security Researcher

 ---
**Contact URL:**https://twitter.com/livingbeef
![[Barak Sternberg_0.png]]
**Contact URL:**https://livingbeef.blogspot.com/
![[Barak Sternberg_1.png]]
**Contact URL:**https://www.linkedin.com/in/barakolo/
**Contact URL:**https://www.barakolo.me
![[Barak Sternberg_3.png]]

 ---
Barak Sternberg is an Experienced Security Researcher who specializes in Offensive Security. 
Founder of "WildPointer", and previously an author at SentinelLabs ("Hacking smart devices for fun and profit", Defcon 2020 IoT Village) and leading innovative cybersecurity research.