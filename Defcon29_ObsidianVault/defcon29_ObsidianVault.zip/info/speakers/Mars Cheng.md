# Mars Cheng
 Threat researcher for TXOne Networks

 ---
**Contact URL:**https://twitter.com/marscheng_
![[Mars Cheng_0.png]]

 ---
Mars Cheng (@marscheng_) is a threat researcher for TXOne Networks, blending a background and experience in both ICS/SCADA and enterprise cybersecurity systems. Mars has directly contributed to more than 10 CVE-IDs, and has had work published in three Science Citation Index (SCI) applied cryptography journals. Before joining TXOne, Mars was a security engineer at the Taiwan National Center for Cyber Security Technology (NCCST). Mars is a frequent speaker and trainer at several international cyber security conferences such as Black Hat Europe, SecTor, FIRST, HITB, ICS Cyber Security Conference Asia and USA, HITCON, SINCON, CYBERSEC, CLOUDSEC and InfoSec Taiwan as well as other conferences and seminars related to the topics of ICS and IoT security. Mars is general coordinator of HITCON (Hacks in Taiwan Conference) 2021 and was vice general coordinator of HITCON 2020.