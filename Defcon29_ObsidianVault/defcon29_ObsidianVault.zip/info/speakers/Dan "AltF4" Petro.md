# Dan "AltF4" Petro
 Lead Researcher, Bishop Fox

 ---
**Contact URL:**https://twitter.com/2600AltF4
![[Dan "AltF4" Petro_0.png]]

 ---
Dan "AltF4" Petro is Lead Researcher at Bishop Fox. Dan is widely known for the tools he creates: Eyeballer (a convolutional neural network pentest tool), the Rickmote Controller (a Chromecast-hacking device), Untwister (pseudorandom number generator cracker), and SmashBot (a merciless Smash Bros noob-pwning machine).