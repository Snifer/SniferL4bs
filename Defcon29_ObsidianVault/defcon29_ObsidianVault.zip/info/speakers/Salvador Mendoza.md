# Salvador Mendoza
 Security Researcher, Ocelot Offensive Security Team

 ---
**Contact URL:**https://twitter.com/Netxing
![[Salvador Mendoza_0.png]]
**Contact URL:**https://salmg.net
![[Salvador Mendoza_1.png]]

 ---
Salvador Mendoza is a Metabase Q security researcher and member of the Ocelot Offensive Security Team.