# Steven Seeley
 Security Researcher of Qihoo 360

 ---
**Contact URL:**https://twitter.com/steventseeley
![[Steven Seeley_0.png]]

 ---
Steven Seeley (@mr_me) is a member of the 360 Vulcan team and enjoys finding and exploiting bugs. Currently his focus is on web and cloud tech and has over 10 years experiance in offensive security. Steven won the Pwn2Own Miami competition with his team mate Chris Anastasio in early 2020 and has taught several classes in web security including his own, Full Stack Web Attack.