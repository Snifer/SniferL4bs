# Kelly Kaoudis
 

 ---
**Contact URL:**https://twitter.com/kaoudis
![[Kelly Kaoudis_0.png]]
**Contact URL:**https://github.com/kaoudis
![[Kelly Kaoudis_1.png]]

 ---
Kelly Kaoudis is a senior software engineer working in application security in Colorado. Following working with the group to validate and test the node-netmask bypass Viale discovered, Kaoudis wrote many of the proofs-of-concept which demonstrate the critical impact of this cascade of unique vulnerabilities.