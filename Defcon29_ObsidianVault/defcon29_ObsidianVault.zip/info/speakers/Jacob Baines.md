# Jacob Baines
 Vulnerability researcher at Dragos

 ---

 ---
Jacob is a vulnerability researcher at Dragos. He enjoys focusing much of his research time on routers and other embedded devices. Occasionally, he finds himself looking at Windows internals. Sometimes he even finds vulnerabilities.