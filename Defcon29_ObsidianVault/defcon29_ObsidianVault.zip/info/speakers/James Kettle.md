# James Kettle
 Director of Research, PortSwigger Web Security

 ---
**Contact URL:**https://twitter.com/albinowax
![[James Kettle_0.png]]
**Contact URL:**https://skeletonscribe.net/
![[James Kettle_1.png]]

 ---
James Kettle is Director of Research at PortSwigger Web Security, where he cultivates novel web attack techniques. Recent work has focused on HTTP Request Smuggling, and using web cache poisoning to turn caches into exploit delivery systems. Past research includes server-side RCE via Template Injection, client-side RCE via malicious formulas in CSV exports, and abusing the HTTP Host header to poison password reset emails and server-side caches. He is also the author of multiple popular Burp Suite extensions including HTTP Request Smuggler, Param Miner and Turbo Intruder. He has spoken at numerous prestigious venues including DEF CON, both BlackHat USA and EU, and OWASP AppSec USA and EU.