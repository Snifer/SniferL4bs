# Eric Betts
 

 ---
**Contact URL:**https://twitter.com/aguynamedbettse 
![[Eric Betts_0.png]]

 ---
Eric Betts is an exuberant, passionate, pragmatic software engineer. He is an avid open-source contributor. He likes to buy all the latest gadgets, and then take them apart. His claim to fame is making $10k from Snapchat (without taking his clothes off) for an RCE bug bounty. He responds to "Bettse" both online and in-person.