# Rotem Bar
 Head of Marketplace Integrations @ Cider Security

 ---
**Contact URL:**https://twitter.com/rotembar
![[Rotem Bar_0.png]]
**Contact URL:**http://www.rotem-bar.com
![[Rotem Bar_1.png]]

 ---
Rotem Bar has over a decade of experience in the security field including penetration testing both application and network, design reviews, code reviews, architecture reviews, tech management, and of course development.