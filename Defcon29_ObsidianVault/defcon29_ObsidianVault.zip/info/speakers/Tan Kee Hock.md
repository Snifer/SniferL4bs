# Tan Kee Hock
 Cybersecurity Specialist, Government Technology Agency of Singapore

 ---
**Contact URL:**https://www.linkedin.com/in/tankeehock/

 ---
Tan Kee Hock is a Cybersecurity Specialist who simply likes to 'hack' things. He loves to play CTFs and is always keen to explore more!