# Sylvain Afchain
 Staff Engineer at Datadog

 ---

 ---
Sylvain Afchain is a staff software engineer at Datadog. He's been working on linux for more than 15 years. He mostly worked on distributed systems, cloud infrastructure and SDN solutions. In his spare time, he enjoys cycling, playing tennis and badminton.