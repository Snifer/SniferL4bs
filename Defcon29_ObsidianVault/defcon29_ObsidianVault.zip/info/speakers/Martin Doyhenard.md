# Martin Doyhenard
 Security Researcher at Onapsis

 ---
**Contact URL:**https://twitter.com/tincho_508
![[Martin Doyhenard_0.png]]

 ---
Martin is a security researcher at the Onapsis Research Labs. His work includes performing security assessment on SAP and Oracle products and detecting vulnerabilities in ERP systems. His research is focused on Web stack security, reverse engineering and binary analisis, and he is also an active CTF player.

Martin has spoken at different conferences including RSA, Troopers, Hack In The Box and EkoParty and presented multiple critical vulnerabilities.