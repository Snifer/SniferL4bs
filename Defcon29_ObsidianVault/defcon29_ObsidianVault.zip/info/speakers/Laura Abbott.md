# Laura Abbott
   Oxide Computer Company

 ---
**Contact URL:**https://twitter.com/openlabbott
![[Laura Abbott_0.png]]

 ---
Laura Abbott is a software engineer who focuses on low level software. Her background includes Linux kernel development with work in the memory management and security areas as well as ARM enablement.