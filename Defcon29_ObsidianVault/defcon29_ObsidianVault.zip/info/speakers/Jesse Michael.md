# Jesse Michael
 HAcker

 ---
**Contact URL:**https://twitter.com/JesseMichael
![[Jesse Michael_0.png]]

 ---
Jesse Michael is an experienced security researcher focused on vulnerability detection and mitigation who has worked at all layers of modern computing environments from exploiting worldwide corporate network infrastructure down to hunting vulnerabilities inside processors at the hardware design level. His primary areas of expertise include reverse engineering embedded firmware and exploit development. He has also presented research at DEF CON, Black Hat, PacSec, Hackito Ergo Sum, Ekoparty, and BSides Portland.