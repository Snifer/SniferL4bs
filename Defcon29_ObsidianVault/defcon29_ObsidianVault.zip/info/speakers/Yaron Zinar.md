# Yaron Zinar
 Sr. Manager, Engineering, CrowdStrike

 ---
**Contact URL:**https://twitter.com/YaronZi
![[Yaron Zinar_0.png]]

 ---
Yaron Zinar is a Sr. Manager at CrowdStrike working on Identity Protection products (previously Preempt). Previously, Yaron spent over 16 years at leading companies such as Google where he held various positions researching and leading big data, machine learning and cyber security projects. Yaron is an expert on Windows Authentication protocols and has previously presented his research at top conferences such as Black Hat and DEFCON. Yaron holds an M.Sc. in Computer Science with focus on statistical analysis.