# Tamas K Lengyel
 Senior Security Researcher, Intel

 ---
**Contact URL:**https://twitter.com/tklengyel
![[Tamas K Lengyel_0.png]]

 ---
Tamas works as Senior Security Researcher at Intel. He received his PhD in Computer Science from the University of Connecticut where he built hypervisor-based malware-analysis and collection tools. In his free time he is maintainer of the Xen Project Hypervisor's VMI subsystem, LibVMI & the DRAKVUF binary analysis project. He currently serves as the Chief Research Officer at The Honeynet Project, a leading international non-profit organization that coordinates the development of open-source tools to fight against malware. Tamas gave prior talks at conferences such as BlackHat, CCC and Hacktivity.