# Rogan Dawes
 Researcher, Orange Cyberdefense’s SensePost Team

 ---
**Contact URL:**https://twitter.com/RoganDawes
![[Rogan Dawes_0.png]]

 ---
Rogan Dawes is a senior researcher at SensePost and has been hacking since 1998, which, coincidentally, is also the time he settled on a final wardrobe. He used the time he saved on choosing outfits to live up to his colleague’s frequent joke that he has an offline copy of the Internet in his head. Rogan spent many years building web application assessment tools, and is credited as having built one of the first and most widely used intercepting proxies; WebScarab. In recent years, Rogan has turned his attentions towards hardware hacking; and these days many suspect him to be at least part cyborg. A good conversation starter is to ask him where he keeps his JTAG header.