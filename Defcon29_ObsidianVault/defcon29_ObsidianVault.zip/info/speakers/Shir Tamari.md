# Shir Tamari
 Head of Research, Wiz (Wiz.io)

 ---
**Contact URL:**https://twitter.com/shirtamari
![[Shir Tamari_0.png]]

 ---
Shir Tamari is a security and technology researcher, specializing in vulnerability research and practical hacking. Works as Head of Research at the cloud security company Wiz. In the past, he served in the Israeli intelligence unit, and in recent years has led a variety of research and security products in the industry. Shir's interests include Android, Linux Kernel, Web hacking and Blockchain.