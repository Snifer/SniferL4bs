# Guillaume Fournier
 Security Engineer at Datadog

 ---
**Contact URL:**https://twitter.com/gui774ume
![[Guillaume Fournier_0.png]]

 ---
Guillaume Fournier is a Security Engineer at Datadog where he focuses on developing a new generation of runtime security tools powered by eBPF. In his free time, he likes to build defensive and offensive security tools such as a chrome-like sandbox for VLC on Linux, or various projects to automate drones and wireless keyboards hacking.