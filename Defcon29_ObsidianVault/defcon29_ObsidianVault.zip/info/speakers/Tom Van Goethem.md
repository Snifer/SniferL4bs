# Tom Van Goethem
 Researcher, KU Leuven

 ---
**Contact URL:**https://twitter.com/tomvangoethem
![[Tom Van Goethem_0.png]]

 ---
Tom Van Goethem is a researcher with the DistriNet group at KU Leuven in Belgium, mainly focusing on practical side-channel attacks against web applications and browsers. By exposing flaws that result from the unintended interplay of different components or network layers, Tom aims to bring us closer to a more secure web that we all deserve. He has spoken at various venues such as Black Hat USA and Asia, OWASP Global, and USENIX Security. In his spare time, Tom provides animal sculptures with pink tutus.