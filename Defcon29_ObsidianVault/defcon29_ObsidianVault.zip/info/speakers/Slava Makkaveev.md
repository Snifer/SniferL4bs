# Slava Makkaveev
 Security Researcher, Check Point

 ---

 ---
Slava Makkaveev is a Security Researcher at Check Point Software Technologies Ltd. Holds a PhD in Computer Science. Slava has found himself in the security field more than ten years ago and since that gained vast experience in reverse engineering and vulnerability research. Recently Slava has taken a particularly strong interest in mobile platforms and firmware security.