# Justin Perdok
 Security Specialist, Orange Cyberdefense Netherlands

 ---
**Contact URL:**https://twitter.com/justinperdok
![[Justin Perdok_0.png]]

 ---
Justin is a Security Specialist at Orange Cyberdefense. Prior to working in 'The Cybers' he has worked at multiple MSPs as a jack of all trades with a focus on security and automation. Stuck in his old ways he's always trying to learn new things; Followed up by him spending 6 hours automating the 'new thing' instead of relying on 5 minutes of manual labor.