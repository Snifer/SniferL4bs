# Cedric Owens
 Offensive Security Engineer

 ---
**Contact URL:**https://medium.com/@cedowens
![[Cedric Owens_0.png]]
**Contact URL:**https://github.com/cedowens
![[Cedric Owens_1.png]]
**Contact URL:**https://twitter.com/cedowens
![[Cedric Owens_2.png]]

 ---
Cedric is currently an offensive security engineer who came from a blue team background. His passion revolves around red teams and blue teams working closely together to improve each other's tradecraft. Cedric enjoys researching techniques and writing tools related to macOS post exploitation and infrastructure automation.