# Roy Davis
 Senior Security Engineer, Zoom Video Communications


 ---
**Contact URL:**https://twitter.com/hack_all_things

![[Roy Davis_0.png]]
**Contact URL:**https://www.linkedin.com/in/roy-davis/
**Contact URL:**https://www.davisinfosec.com
![[Roy Davis_2.png]]

 ---
Roy Davis is a security researcher and engineer with 15 years of pentesting, security research and programming experience. He has worked on security teams at Zoom, Salesforce, Apple, Barclays Bank, and Thomson Reuters. He holds a B.S. degree in Computer Science from Purdue University and an M.S. in Cybersecurity and Digital Forensics from WGU. Roy has presented at several security conferences from 2008 to his most recent talk at the “HackerOne Security@” conference in San Francisco.