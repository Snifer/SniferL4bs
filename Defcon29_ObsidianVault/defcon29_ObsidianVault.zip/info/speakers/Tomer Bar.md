# Tomer Bar
 Director of Security Research @ SafeBreach

 ---

 ---
Tomer Bar is hands-on security researcher and head of research manager with ~20 years of unique experience in the cyber security. In the Past, he ran research groups for the Israeli government and then lead the endpoint malware research for Palo Alto Networks. Currently, he leads the SafeBreach Labs research which is the research and development arm of SafeBreach.