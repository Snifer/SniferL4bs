# Eyal Karni
 Sr. Engineer, CrowdStrike

 ---
**Contact URL:**https://twitter.com/eyal_karni
![[Eyal Karni_0.png]]

 ---
Eyal Karni is a Sr. Engineer at CrowdStrike working on Identity Protection products (previously Preempt). Eyal spent over 11 years researching cyber security projects. Previously, he served 5 years in an elite unit of the IDF in Cyber Security Research and Development. Eyal is an expert on Windows Internals and has previously found numerous vulnerabilities. Eyal holds a B.Sc in Mathematics and Physics.