# Austin Allshouse
 Staff Research Scientist / BitSight

 ---
**Contact URL:**https://twitter.com/AustinAllshouse
![[Austin Allshouse_0.png]]

 ---
Austin Allshouse is a Research Scientist at BitSight where he applies
information security, statistical modeling, and distributed computing
concepts to develop quantitative methods of assessing security risk.
He has a decade of experience researching the technologies and
methodologies underpinning digital network surveillance systems.