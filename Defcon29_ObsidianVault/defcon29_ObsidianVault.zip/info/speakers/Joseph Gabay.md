# Joseph Gabay
 Hacker

 ---

 ---
Joseph is a robotics engineer in Boston, Massachusetts where he works on a variety of projects ranging from electromechanical designs to embedded systems.