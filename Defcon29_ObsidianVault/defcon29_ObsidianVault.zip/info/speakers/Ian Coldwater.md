# Ian Coldwater
 Hacker

 ---
**Contact URL:**https://twitter.com/IanColdwater
![[Ian Coldwater_0.png]]

 ---
Ian is a leading expert on containers and container security.