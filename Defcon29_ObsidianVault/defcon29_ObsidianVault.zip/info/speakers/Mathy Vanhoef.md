# Mathy Vanhoef
 Postdoctoral Researcher, NYU

 ---
**Contact URL:**https://twitter.com/vanhoefm
![[Mathy Vanhoef_0.png]]

 ---
Mathy Vanhoef is a postdoctoral researcher at New York University Abu Dhabi. His research interest lies in computer security with a focus on network and wireless security (e.g. Wi-Fi), software security, and applied cryptography. In these areas Mathy tries to bridge the gap between real-world code and (protocol) standards. He previously discovered the KRACK attack against WPA2, the RC4 NOMORE attack against RC4, and the Dragonblood attack against WPA3.