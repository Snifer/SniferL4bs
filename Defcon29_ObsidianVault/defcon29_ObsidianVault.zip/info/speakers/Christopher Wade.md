# Christopher Wade
 Security Consultant at Pen Test Partners

 ---
**Contact URL:**https://twitter.com/Iskuri1
![[Christopher Wade_0.png]]
**Contact URL:**https://github.com/Iskuri
![[Christopher Wade_1.png]]

 ---
Christopher is a seasoned security researcher and consultant. His main focuses are in reverse engineering hardware, fingerprinting USB vulnerabilities and playing with Software Defined Radios, with his key strength lying in firmware analysis, which he utilizes as part of the hardware testing team at Pen Test Partners.