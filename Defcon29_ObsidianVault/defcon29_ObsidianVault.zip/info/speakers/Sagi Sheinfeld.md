# Sagi Sheinfeld
 Sr. Engineer, CrowdStrike


 ---
**Contact URL:**https://twitter.com/sagish1233
![[Sagi Sheinfeld_0.png]]

 ---
Sagi Sheinfeld is a Sr. Engineer at CrowdStrike working on Identity Protection products (previously Preempt). Sagi spent over 14 years researching cyber security projects. Previously, he served 8 years in an elite unit of the IDF in Cyber Security Research and Development and in IBM Security. Sagi is an expert on Windows internals. Sagi holds a B.Sc in Computer Science.