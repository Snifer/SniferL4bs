# Stephanie Domas
Director of Cybersecurity Strategy and Communications at Intel

 ---

 ---
Stephanie Domas is the Director of Cybersecurity Strategy and Communications at Intel. Here, she leads development of complex security strategies for the critical role that hardware and firmware security play in the digital ecosystem. Prior to Intel, Stephanie was spent 8 years focused on medical device cybersecurity, consulting with a broad range of manufacturers from the newest startups to the industry giants. She is the founder and lead trainer for cybersecurity training company DazzleCatDuo. Her past experience includes 10 years of reverse engineering and vulnerability analysis research as a defense contractor. Stephanie is a recognized expert on embedded systems, healthcare and medical device security, a seasoned executive, a prominent consultant, a passionate educator, and x86 enthusiast.