# Katie Whiteley
 MKFactor.com

 ---
**Contact URL:**https://twitter.com/ktjgeekmom
![[Katie Whiteley_0.png]]

 ---
Katie is a wife, mother, and graphic designer. She likes long walks on the beach because there's no internet connection.