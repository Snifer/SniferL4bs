# Bill Graydon
 Principal, Research, GGR Security 

 ---
**Contact URL:**https://twitter.com/access_ctrl
![[Bill Graydon_0.png]]
**Contact URL:**https://github.com/bgraydon
![[Bill Graydon_1.png]]
**Contact URL:**https://www.youtube.com/channel/UCzZK3vjJL9rKNPXNoCPFO5g/videos
![[Bill Graydon_2.png]]

 ---
Bill Graydon is a principal researcher at GGR Security, where he hacks everything from locks and alarms to critical infrastructure; this has given him some very fine-tuned skills for breaking stuff.  He’s passionate about advancing the security field through research, teaching numerous courses, giving talks, and running DEF CON’s Lock Bypass Village.  He’s received various degrees in computer engineering, security, and forensics and comes from a broad background of work experience in cyber security, software development, anti-money laundering, and infectious disease detection.