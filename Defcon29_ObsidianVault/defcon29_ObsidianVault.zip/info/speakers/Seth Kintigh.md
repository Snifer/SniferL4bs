# Seth Kintigh
 Hardware Security Engineer, Dell

 ---

 ---
Seth Kintigh learned to program at age 12 on an IBM PC jr and his grandmother taught him how to crack ciphers. His first hack was to get infinite lives and beat the Atari 2600 game Solaris. He earned a BS EE with minors in CS and physics and a MS EE with concentration in cryptography and information security from WPI. He worked 6 years as a hardware engineer and 17 in security. Hobbies include cracking historical ciphers and restoring a Victorian home