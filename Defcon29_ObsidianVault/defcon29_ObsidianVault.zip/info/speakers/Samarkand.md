# Samarkand
 CEO at Samarkand Web Studio.

 ---
**Contact URL:**https://samarkand.000space.com/
**Contact URL:**https://thesamarkand.tumblr.com/
![[Samarkand_1.png]]

 ---
Samarkand is painter, student of Economic faculty and CEO of Samarkand Web Studio.

He works as freelance security researcher at https://freelancehunt.com/freelancer/thesamarkand.html