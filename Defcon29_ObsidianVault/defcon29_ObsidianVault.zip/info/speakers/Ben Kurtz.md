# Ben Kurtz
 Principal Anarchist, SymbolCrash
Founder of Binject, Host of the Hack the Planet podcast

 ---
**Contact URL:**https://twitter.com/symbolcrash1
![[Ben Kurtz_0.png]]
**Contact URL:**https://symbolcrash.com
![[Ben Kurtz_1.png]]

 ---
Ben Kurtz is a hacker, a hardware enthusiast, and the host of the Hack the Planet podcast (https://symbolcrash.com/podcast). After his first talk, at DefCon 13, he ditched development and started a long career in security. 
He has been a pentester for IOActive, head of security for an MMO company, and on the internal pentest team for the Xbox One at Microsoft.  Along the way, he volunteered on anti-censorship projects, which resulted in his conversion
to Golang and the development of the ratnet project (https://github.com/awgh/ratnet).  A few years ago, he co-founded the Binject group to develop core offensive components for Golang-based malware, and Symbol Crash, which focuses on
sharing hacker knowledge through trainings for red teams, a free monthly Hardware Hacking workshop in Seattle, and podcasts.  He is currently developing a ratnet-based handheld device for mobile encrypted mesh messenging, planned for
release next year.