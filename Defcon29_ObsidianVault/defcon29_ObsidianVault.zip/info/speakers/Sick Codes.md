# Sick Codes
 Hacker

 ---
**Contact URL:**https://twitter.com/sickcodes
![[Sick Codes_0.png]]
**Contact URL:**https://sick.codes
![[Sick Codes_1.png]]
**Contact URL:**https://github.com/sickcodes
![[Sick Codes_2.png]]
**Contact URL:**https://www.linkedin.com/in/sickcodes/

 ---
Sick Codes maintains popular open source projects, publishes high-profile security vulnerabilities in good faith, and administers his namesake https://sick.codes, a security research and tutorial resource for developers. Sick Codes' work coordinating communication across many companies, foundations, and other open source organisations was invaluable in getting these vulnerabilities patched and responsibly disclosed.