# Kurtis Minder
CEO, GroupSense

 ---

 ---
