# Richard Thieme AKA neuralcowboy
 author and professional speaker, ThiemeWorks

 ---
**Contact URL:**https://twitter.com/neuralcowboy
![[Richard Thieme AKA neuralcowboy_0.png]]

 ---
Richard Thieme, https://thiemeworks.com has addressed security and intelligence issues for 28 years. He has keynoted security conferences in 15 countries and given presentations for the NSA, FBI, Secret Service, Pentagon Security Forum, U.S. Department of the Treasury, and Los Alamos National Laboratory. He has been speaking at Def Con since Def Con 4. His sixth book, a novel, Mobius: A Memoir, about an intelligence professional looking back on his career and how it led down unexpected paths, is receiving rave reviews. He has explored UFO phenomena seriously for 43 years.