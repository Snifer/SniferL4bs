# Jessica Wilkerson
Cyber Policy Advisor at the US Food and Drug Administration FDA

 ---

 ---
Jessica Wilkerson is a Cyber Policy Advisor with the All Hazards Readiness, Response, and Cybersecurity (ARC) team in the Center for Devices and Radiological Health (CDRH) within the Food and Drug Administration (FDA). As part of ARC, she examines issues and develops policy related to the safety and effectiveness of connected medical devices. She received a B.A. in Policy Studies and minors in Computer Science and Mathematics from Syracuse University, and is currently pursuing a J.D. from the Catholic University of America’s Columbus School of Law.