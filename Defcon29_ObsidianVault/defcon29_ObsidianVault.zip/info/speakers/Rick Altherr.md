# Rick Altherr
   Oxide Computer Company

 ---
**Contact URL:**https://twitter.com/kc8apf
![[Rick Altherr_0.png]]

 ---
Rick Altherr has a career ranging from ASICs to UX with a focus on the intersection of hardware and software, especially in server systems.  His past work includes USBAnywhere, leading the unification of OpenBMC as a project under Linux Foundation, co-authoring a whitepaper on Google’s Titan, and reverse engineering Xilinx 7 Series FPGA bitstreams as part of prjxray.