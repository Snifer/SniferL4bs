# Ian Vitek
 Security, Sveriges Riksbank (Central bank of Sweden)

 ---

 ---
Ian Vitek has a background as a pentester but has worked with information security in the Swedish financial sector the last 10 years. Currently working with security of the Swedish retail central bank digital currency prototype at the Riksbank, the Swedish central bank. Interested in web application security, network layer 2 (the writer of macof), DMA attacks and local pin bypass attacks (found some on iPhone).