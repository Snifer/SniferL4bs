# Allan Cecil (dwangoAC)
Security Consultant, Bishop Fox

 ---
**Contact URL:**https://twitter.com/mrtasbot
![[Allan Cecil (dwangoAC)_0.png]]

 ---
Allan Cecil (dwangoAC) is a Security Consultant with Bishop Fox and the President of the North Bay Linux User’s Group. He acts as an ambassador for Tasvideos.org, a website devoted to using emulators to complete video games as quickly as the hardware allows. He participates in Games Done Quick charity speed running marathons using TASBot to entertain viewers with never-before-seen glitches in games.