# Reza Soosahabi
 Senior R&D Engineer, Keysight Technologies

 ---
**Contact URL:**https://twitter.com/darthsohos
![[Reza Soosahabi_0.png]]
**Contact URL:**https://scholar.google.com/citations?user=SNFxK60AAAAJ&hl=en
![[Reza Soosahabi_1.png]]

 ---
Reza Soosahabi is a lead R&D engineer with Application & Threat Intelligence Research Center (ATIRC) at Keysight Technologies. His current field of research includes RAN security, data exfiltration and ML / statistical algorithms. He has been a 5G system engineer prior to joining Keysight in 2018. He contributes in IEEE proceedings related to signal processing and information security.  As a math-enthusiast, Reza often tries unconventional analytical approaches to discover and solve technically diverse problems. He also enjoys cutting boxes with Occam’s Razor and encourages the others around him to do so.