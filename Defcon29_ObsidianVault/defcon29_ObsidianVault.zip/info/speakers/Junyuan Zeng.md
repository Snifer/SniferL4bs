# Junyuan Zeng
 Senior Software Engineer, Linkedin

 ---
**Contact URL:**https://www.linkedin.com/in/junyuanzeng/

 ---
Junyuan Zeng is Senior Software Engineer at Linkedin. Before Linkedin, he was Staff Security Architect at JD.com where he designed and architected container security monitoring solutions. Before that he was Staff Software Engineer for mobile payment security at Samsung and a security researcher at FireEye where he worked on mobile malware analysis. He has published in ACM CCS, USENIX ATC, and other top academic conferences. He obtained his PhD in Computer Science from The University of Texas at Dallas.