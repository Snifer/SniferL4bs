# Zhiniang Peng
 Principal Security Researcher at Sangfor

 ---
**Contact URL:**https://twitter.com/edwardzpeng
![[Zhiniang Peng_0.png]]

 ---
Dr. Zhiniang Peng (@edwardzpeng) is the Principal Security Researcher at Sangfor. His current research areas include applied cryptography, software security and threat hunting. He has more than 10 years of experience in both offensive and defensive security and published much research in both academia and industry.