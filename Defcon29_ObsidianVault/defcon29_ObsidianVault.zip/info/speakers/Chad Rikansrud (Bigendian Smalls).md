# Chad Rikansrud (Bigendian Smalls)
 Hacker

 ---
**Contact URL:**https://twitter.com/bigendiansmalls
![[Chad Rikansrud (Bigendian Smalls)_0.png]]

 ---
Chad is the same, but for mainframes and mainframe security.