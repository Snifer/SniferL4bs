# Dimitry "Op_Nomad" Snezhkov
Associate Director, Protiviti 

 ---
**Contact URL:**https://twitter.com/Op_Nomad
![[Dimitry "Op_Nomad" Snezhkov_0.png]]
**Contact URL:**https://twitter.com/Op_Nomad
![[Dimitry "Op_Nomad" Snezhkov_1.png]]

 ---
Dimitry Snezhkov is an Associate Director at Protiviti. In this role he hacks code, tools, networks, apps and sometimes subverts human behavior too. Dimitry has spoken at DEF CON, BlackHat, THOTCON conferences, and presented tools at BlackHat Arsenal.