# Glenice Tan
 Cybersecurity Specialist, Government Technology Agency of Singapore

 ---
**Contact URL:**https://www.linkedin.com/in/glenicetan/

 ---
Glenice is a security researcher that enjoys exploring the quirks of different systems, applications, and processes. In the past year, she had the opportunity to conduct social engineering exercises, which includes phishing and vishing. Apart from applications and human hacking, she also experiments on ways to automate or improve red team operations.