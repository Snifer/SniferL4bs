# Orange Tsai
 Principal Security Researcher of DEVCORE

 ---
**Contact URL:**https://twitter.com/orange_8361
![[Orange Tsai_0.png]]
**Contact URL:**https://blog.orange.tw/
![[Orange Tsai_1.png]]

 ---
Cheng-Da Tsai, aka Orange Tsai, is the principal security researcher of DEVCORE, CHROOT security group member, and captain of HITCON CTF team in Taiwan. He is the Pwn2Own 2021 "Master of Pwn" champion and also as the speaker in conferences such as Black Hat USA/ASIA, DEF CON, HITCON, HITB GSEC/AMS, CODE BLUE, and WooYun!