# Paz Hameiri
 Hacker

 ---
**Contact URL:**https://il.linkedin.com/in/paz-hameiri-251b11143

 ---
Paz started his professional life 30 years ago, hacking games and developing tools in his teen years. Since then, he has worked in several companies, developing both hardware and software.