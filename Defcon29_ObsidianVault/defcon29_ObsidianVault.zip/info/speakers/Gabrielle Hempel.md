# Gabrielle Hempel
Cloud Security Engineer/Medical Security Researcher

 ---
**Contact URL:**https://twitter.com/gabsmashh
![[Gabrielle Hempel_0.png]]

 ---
I am a graduate of the University of Cincinnati, where I studied Neuroscience and Psychology with a minor in Criminal Justice. I started out at an institutional review board in regulatory pharmaceutical and medical device compliance, and led specialized committees targeting Phase I research and emergency research. I moved to IT consulting in 2018, and currently work as a Security Engineer in healthcare while pursuing an MS in Global Security, Conflict, and Cybercrime at NYU. I continue to serve as a genetic scientist for NIH-regulated recombinant genetic studies, and sit on multiple advisory boards. My continued areas of focus include medical device security, connected healthcare security, and the intersections of the healthcare and information security industries.