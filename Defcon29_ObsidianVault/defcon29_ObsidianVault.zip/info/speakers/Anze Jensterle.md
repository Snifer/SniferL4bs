# Anze Jensterle
 

 ---
**Contact URL:**https://twitter.com/applejacksec 
![[Anze Jensterle_0.png]]

 ---
Anze Jensterle is a Computer Science student by day, professional door opener by night that comes from Slovenia (not Slovakia). Having been involved with InfoSec since he was 17, when he made his first bug bounty, he has continuously been developing his skills in different areas including Web, RFID and Embedded System Security.