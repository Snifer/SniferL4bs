# Claire Vacherot
 Senior Security Auditor @ Orange Cyberdefense

 ---

 ---
Claire Vacherot is a pentester at Orange Cyberdefense. She likes to test systems and devices that interact with the real world and is particularly interested in industrial and embedded device cybersecurity. As a former software developer, she never misses a chance to write scripts and tools.