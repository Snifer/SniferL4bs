# HTTP/2: The Sequel is Always Worse

 ---
HTTP/2 is easily mistaken for a transport-layer protocol that can be swapped in with zero security implications for the website behind it. Two years ago, I presented HTTP Desync Attacks and kicked off a wave of request smuggling, but HTTP/2 escaped serious analysis. In this presentation, I'll take you beyond the frontiers of existing HTTP/2 research, to unearth horrifying implementation flaws and subtle RFC oversights.

I'll show you how these flaws enable HTTP/2-exclusive desync attacks, with case studies targeting high-profile websites powered by servers ranging from Amazon's Application Load Balancer to WAFs, CDNs, and bespoke stacks by big tech. I'll demonstrate critical impact by hijacking thick clients, poisoning caches, and stealing plaintext passwords to net multiple max-bounties.

After that, I'll unveil novel techniques and tooling to crack open a widespread but overlooked request smuggling variant affecting both HTTP/1 and HTTP/2 that is typically mistaken for a false positive.

Finally, I'll drop multiple exploit-primitives that resurrect a largely-forgotten class of vulnerability, and use HTTP/2 to expose fresh application-layer attack surface.

I'll leave you with an open-source scanner, a custom, open-source HTTP/2 stack, and free interactive labs so you can hone your new skills on live systems.


REFERENCES:
The HTTP/2 RFC is essential reading: https://tools.ietf.org/html/rfc7540

This research is built on my previous work on this topic:
https://portswigger.net/research/http-desync-attacks-request-smuggling-reborn

This presentation by defparam has good explanations of response queue poisoning and self-desync attacks:
https://www.youtube.com/watch?v=3tpnuzFLU8g

I had a partial research collision with Emil Lerner. His work provides an alternative perspective on certain techniques:
https://github.com/neex/http2smugl


 ---
**Tags**:
#passwords #websites #research #impact 
 **Speakers**:
[[James Kettle]]
