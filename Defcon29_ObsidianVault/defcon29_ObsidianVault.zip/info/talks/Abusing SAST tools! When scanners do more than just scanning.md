# Abusing SAST tools! When scanners do more than just scanning

 ---
When we write code, we often run many scanners for different purposes on our code - from linters, to testing, security scanning, secret scanning, and more.

Scanning the code occurs on developers' machines and in CI/CD pipelines, which assumes the code is untrusted and unverified and based on this assumption scanners shouldn't have the ability to dynamically run code.

Our research focuses on the many static analyzers out there if this is really the case. Many of the scanners allow different ways of interaction - From requesting external resources, overriding the configuration and to remote code execution as part of the process.This talk will be technical and show examples of well-known scanning tools and how we created code that attacks them.

TLDR -
When integrating and using new tools in our CI systems and especially when running on unverified code, Which tools can we trust and how can we scan safe untrusted code in a secure way?



REFERENCES:
https://github.com/jonase/kibit/issues/235 - Issue I raised in the past in one of the tools

Hiroki Suezawa in a thread in cloud security forum talked about exploiting terraform plan https://cloudsecurityforum.slack.com/archives/CNJKBFXMH/p1584035704035800

This reference was released after I've started my research but nevertheless a good resource and has interesting perspectives and I will reference it:
https://alex.kaskaso.li/post/terraform-plan-rce

 ---
**Tags**:
#attacks #trust #tools #configuration #research #scan #cloud 
 **Speakers**:
[[Rotem Bar]]
