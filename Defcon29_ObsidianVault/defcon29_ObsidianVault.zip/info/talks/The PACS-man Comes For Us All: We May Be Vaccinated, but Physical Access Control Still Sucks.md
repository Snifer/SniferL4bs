# The PACS-man Comes For Us All: We May Be Vaccinated, but Physical Access Control Still Sucks

 ---
It's 2021. You’re still here! You’re vaccinated! You should be happy and carefree! And yet…the PACS-man still haunts us all. Why should this be? Don’t we have newer, better tech with more bits of encryption and fewer wires? Haven’t the professional sentinels we’ve entrusted with our physical security software-defined ALL THE THINGS and made them better? 
Nay, these are but fruits of the poisonous physical security tree! Come, fellow hackers and weary travelers, visit with the ghosts of access control and learn of the lies they’ve laid before us! 
Come see how false guardians have used BLE slight-of-hand to increase complexity and cost while reducing security and ask that they be paid a tithing for the privilege! 
Witness young software-defined gladiators do battle in an arena they did not prepare for and falter! 
Behold as our friendly ghosts of access control forge never-before seen tools to help slay false security prophets!



 ---
**Tags**:
#encryption #physical #tools 
 **Speakers**:
[[Babak Javadi]]
[[Nick Draffen]]
[[Eric Betts]]
[[Anze Jensterle]]
