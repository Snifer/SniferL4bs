# Why does my security camera scream like a Banshee? Signal analysis and RE of a proprietary audio-data encoding protocol 

 ---
All I wanted was a camera to monitor my pumpkin patch for pests, what I found was a wireless security camera that spoke with an accent and asked to speak with my fax machine. Join me as I engage in a signals analysis of the Amiccom 1080p Outdoor Security Camera and hack the signal to reverse engineer the audio tones used to communicate and configure this inexpensive outdoor camera. This journey takes us through spectrum-analysis, APK decompiling, tone generation in Android and the use of Ghidra for when things REALLY get hairy.

REFERENCES:

- JADX: Dex to Java Decompiler - https://github.com/skylot/jadx
- Efficiency: Reverse Engineering with ghidra - http://wapiflapi.github.io/2019/10/10/efficiency-reverse-engineering-with-ghidra.html
- Guide to JNI (Java Native Interface) - https://www.baeldung.com/jni
- JDSP - Digital Signal Processing in Java - https://psambit9791.github.io/jDSP/transforms.html
- Understanding FFT output - https://stackoverflow.com/questions/6740545/understanding-fft-output
- Spectral Selection and Editing - Audacity Manual - https://manual.audacityteam.org/man/spectral_selection.html
- Edit>Labelled Audio>everything greyed out - https://forum.audacityteam.org/viewtopic.php?t=100856
- Get a spectrum of frequencies from WAV/RIFF using linux command line - https://stackoverflow.com/questions/21756237/get-a-spectrum-of-frequencies-from-wav-riff-using-linux-command-line
- How to interpret output of FFT and extract frequency information - https://stackoverflow.com/questions/21977748/how-to-interpret-output-of-fft-and-extract-frequency-information?rq=1
- Calculate Frequency from sound input using FFT - https://stackoverflow.com/questions/16060134/calculate-frequency-from-sound-input-using-fft?rq=1
- Intorduction - Window Size - https://support.ircam.fr/docs/AudioSculpt/3.0/co/Window%20Size.html
- Android: Sine Wave Generation - https://stackoverflow.com/questions/11436472/android-sine-wave-generation
- Android Generate tone of a specific frequency - https://riptutorial.com/android/example/28432/generate-tone-of-a-specific-frequency
- Android Tone Generator - https://gist.github.com/slightfoot/6330866
- Android: Audiotrack to play sine wave generates buzzing noise - https://stackoverflow.com/questions/23174228/android-audiotrack-to-play-sine-wave-generates-buzzing-noise

 ---
**Tags**:
#linux #wireless #encoding #audio #signal #fax 
 **Speakers**:
[[Rion Carter]]
