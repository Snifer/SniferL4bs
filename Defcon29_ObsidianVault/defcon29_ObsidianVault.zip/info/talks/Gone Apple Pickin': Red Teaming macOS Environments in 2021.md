# Gone Apple Pickin': Red Teaming macOS Environments in 2021

 ---
Though the vast majority of US companies are enterprise Windows shops, there is a growing percentage of companies that are shifting away from this model. Most of these types of companies tend to be based in the SF Bay Area and are often tech companies. This talk will provide a glimpse into what common attack paths in these environments look like in the absence of typical enterprise Active Directory implementations. Examples include techniques for targeting macOS endpoints, cloud and IdaaS, CI/CD pipeline, and other fun approaches. I will begin by discussing common tech stacks and macOS deployments and then move into macOS initial access (including the Gatekeeper bypass I found) and post exploitation options in these modern tech environments as well as detection opportunities.

 ---
**Tags**:
#detection #cloud 
 **Speakers**:
[[Cedric Owens]]
