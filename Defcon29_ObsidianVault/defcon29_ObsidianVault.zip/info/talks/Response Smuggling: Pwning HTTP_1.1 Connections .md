# Response Smuggling: Pwning HTTP/1.1 Connections 

 ---
Over the past few years, we have seen some novel presentations re-introducing the concept of HTTP request smuggling, to reliably exploit complex landscapes and systems. With advanced techniques, researchers were able to bypass restrictions and breach the security of critical web applications.

This presentation will take a new approach, focusing on the response pipeline desynchronization, a rather unexplored attack vector in HTTP Smuggling.

First, I will introduce a Desync variant, using connection-tokens to hide arbitrary headers from the backend. This technique does not abuse discrepancy between HTTP parsers, but instead relies on a vulnerability in the protocol itself!

The issue was found and reported under Google’s Vulnerability Reward Program for a nice bounty!

Next, I will show how it is possible to inject multiple messages at the backend server, mixing the pipeline’s connection order, and hijack users sessions from login requests.

Finally, using a novel technique known as Response Scripting, I will demonstrate how to create malicious outbound messages using static responses as the building blocks. This will be leveraged to write custom responses and take control of one of the most popular protocols in history!

REFERENCES:
RFC 2616: Hypertext Transfer Protocol -- HTTP/1.1
https://tools.ietf.org/html/rfc2616

RFC 7231: Hypertext Transfer Protocol (HTTP/1.1): Semantics and Content
https://tools.ietf.org/html/rfc7231

CHAIM LINHART, AMIT KLEIN, RONEN HELED, STEVE ORRIN:
HTTP Request Smuggling
https://www.cgisecurity.com/lib/HTTP-Request-Smuggling.pdf

James Kettle:
HTTP Desync Attacks: Request Smuggling Reborn
https://portswigger.net/research/http-desync-attacks-request-smuggling-reborn
https://portswigger.net/research/http-desync-attacks-what-happened-next

Emile Fugulin
HTTP Desync Attacks with Python and AWS
https://medium.com/@emilefugulin/http-desync-attacks-with-python-and-aws-1ba07d2c860f

Amit Klein
HTTP Request Smuggling in 2020
https://i.blackhat.com/USA-20/Wednesday/us-20-Klein-HTTP-Request-Smuggling-In-2020-New-Variants-New-Defenses-And-New-Challenges.pdf

 ---
**Tags**:
#exploit #vulnerability #protocols #web #breach #restrictions #login 
 **Speakers**:
[[Martin Doyhenard]]
