# ProxyLogon is Just the Tip of the Iceberg, A New Attack Surface on Microsoft Exchange Server! 

 ---
Microsoft Exchange Server is an email solution widely deployed within government and enterprises, and it is an integral part of both their daily operations and security. Needless to say, vulnerabilities in Exchange have long been the Holy Grail for attackers, hence our security research on Exchange. Surprisingly, we’ve found not only critical vulnerabilities such as ProxyLogon, but a whole new attack surface of Exchange.

This new attack surface is based on a significant change in Exchange Server 2013, where the fundamental protocol handler, Client Access Service (CAS), splits into frontend and backend. In this fundamental change of architecture, quite an amount of design debt was incurred, and, even worse, it introduced inconsistencies between contexts, leading us to discover this new attack surface.

To unveil the beauty of this attack surface and our novel exploitation, we’ll start by analyzing this architecture, followed by 7 vulnerabilities that consist of server-side bugs, client-side bugs, and crypto bugs found via this attack surface. In the end, these vulnerabilities are chained into 3 attack vectors that shine in different attack scenarios: ProxyLogon, ProxyShell, and ProxyOracle. These attack vectors enable any unauthenticated attacker to uncover plaintext passwords and even execute arbitrary code on Microsoft Exchange Servers through port 443, which is exposed to the Internet by ~400K Exchange Servers.

This attack surface has its unparalleled impact for a reason: security researchers tend to find vulnerabilities from a certain perspective, such as digging for memory bugs, injections, or logic flaws, but we took a different approach by looking at Exchange from a high-level architectural view and captured this architecture-level attack surface, which yielded multiple vulnerabilities. We hope this brings a new paradigm to vulnerability research and inspires more security researchers to look into Exchange Server. Last but not least, we’ll provide hardening actions to mitigate such types of 0days in Exchange.

# REFERENCES:
* "Hunting for bugs, catching dragons" by Nicolas Joly in Black Hat USA 2019
* CVE-2020-0688 and CVE-2018-8302 from ZDI blog
* CVE-2020-16875 from @steventseeley

 ---
**Tags**:
#passwords #email #vulnerability #memory #hardening #client-side #government #research #operations #impact #vulnerabilities #crypto 
 **Speakers**:
[[Orange Tsai]]
