# You're Doing IoT RNG

 ---
Think of a random number between '0' and infinity. Was your number '0'? Seriously? Crap. Well unfortunately, the hardware random number generators (RNG) used by your favorite IoT devices to create encryption keys may not work much better than you when it comes to randomness.

In this talk, we'll delve into murky design specs, opaque software libraries, and lots of empirical results. We wrote code for many popular IoT SoC platforms to extract gigabytes of data from their hardware RNGs and analyze them. What we found was a systemic minefield of vulnerabilities in almost every platform that could undermine IoT security. Something needs to change in how the Internet of Things does RNG.

The vulnerabilities are widespread and the attacks are practical. RNG is bad out there - "IoT Crypto-pocalypse" bad.

 ---
**Tags**:
#encryption #attacks #hardware #random #software #vulnerabilities 
 **Speakers**:
[[Dan "AltF4" Petro]]
[[Allan Cecil (dwangoAC)]]
