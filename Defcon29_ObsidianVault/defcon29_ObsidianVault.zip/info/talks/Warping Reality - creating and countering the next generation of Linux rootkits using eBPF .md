# Warping Reality - creating and countering the next generation of Linux rootkits using eBPF 

 ---

With complete access to a system, Linux kernel rootkits are perfectly placed to hide malicious access and activity. However, running code in the kernel comes with the massive risk that any change to a kernel version or configuration can mean the difference between running successfully and crashing the entire system. This talk will cover how to use extended Berkley Packet Filters (eBPF) to create kernel rootkits that are safe, stable, stealthy, and portable.

eBPF is one of the newest additions to the Linux kernel, designed to easily load safe, constrained, and portable programs into the kernel to observe and make decisions about network traffic, syscalls, and more. But that’s not it’s only use: by creating eBPF programs that target specific processes we can warp reality, presenting a version of a file to one program and a different version to another, all without altering the real file on disk. This enables techniques such as presenting a backdoor user to ssh while hiding from sysadmins, or smuggling data inside connections from legitimate programs. This talk will also cover how to use these same techniques in malware analysis to fool anti-sanbox checks.

These ideas and more are explored in this talk alongside practical methods to detect and prevent this next generation of Linux rootkits.

REFERENCES:
- DEFCON 27 - Evil eBPF Practical Abuses of In-kernel Bytecode Runtime
  - A talk about abusing eBPF for exploitation and privilege escalation

- eBPF Website
  - https://ebpf.io
  - A website by the eBPF community with documentation and links to existing projects

- eBPF Slack
  - https://ebpf.io/slack
  - A Slack channel run by the eBPF community

- Libbpf Bootstrap
  - https://github.com/libbpf/libbpf-bootstrap
  - A sample project designed to provide a template to creating eBPF programs with Libbpf
----------------------------

 ---
**Tags**:
#network #malware #ssh #backdoor #rootkits #configuration #kernel #risk #documentation 
 **Speakers**:
[[PatH]]
