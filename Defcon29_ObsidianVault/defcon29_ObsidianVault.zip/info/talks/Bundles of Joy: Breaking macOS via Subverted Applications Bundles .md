# Bundles of Joy: Breaking macOS via Subverted Applications Bundles 

 ---
A recent vulnerability, CVE-2021-30657, neatly bypassed a myriad of foundational macOS security features such as File Quarantine, Gatekeeper, and Notarization. Armed with this capability attackers could (and were!) hacking macOS systems with a simple user (double)-click. Yikes!

In this presentation we’ll dig deep into the bowels of macOS to uncover the root cause of the bug: a subtle logic flaw in the complex and undocumented policy subsystem. Moreover, we’ll highlight the discovery of malware exploiting this bug as an 0day, reversing Apple’s patch, and discuss novel methods of both detection and prevention. 

REFERENCES:
“All Your Macs Are Belong To Us”
https://objective-see.com/blog/blog_0x64.html

“macOS Gatekeeper Bypass (2021 Edition)”
https://cedowens.medium.com/macos-gatekeeper-bypass-2021-edition-5256a2955508


“Shlayer Malware Abusing Gatekeeper Bypass On Macos”
https://www.jamf.com/blog/shlayer-malware-abusing-gatekeeper-bypass-on-macos/

 ---
**Tags**:
#malware #detection #root #policy 
 **Speakers**:
[[Patrick Wardle]]
