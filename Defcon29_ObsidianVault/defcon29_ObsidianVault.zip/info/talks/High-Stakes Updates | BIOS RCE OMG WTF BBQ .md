# High-Stakes Updates | BIOS RCE OMG WTF BBQ 

 ---
With attacks moving below the operating system and computer firmware vulnerability discovery on the rise, the need to keep current platforms updated becomes important and new technology is developed to help defend against such threats. Major computer manufacturers are adding capabilities to make it easier to update BIOS.
Our research has identified multiple vulnerabilities in Dell's BiosConnect feature used for remote update and recovery of the operating system. These vulnerabilities are easy to exploit by an adversary in the right position, and are not prevented by protective technologies such as Secured Core PCs, BitLocker, BootGuard, and BIOS Guard.
Join us and together we will explore the new attack surfaces introduced by these UEFI firmware update mechanisms -- including a full walk-through of multiple vulnerability findings and the methods we used to create fully working exploits that gain remote code execution within the laptop BIOS and their effects on the operating system.

 ---
**Tags**:
#exploit #attacks #vulnerability #firmware #research #recovery #capabilities #vulnerabilities 
 **Speakers**:
[[Mickey Shkatov]]
[[Jesse Michael]]
