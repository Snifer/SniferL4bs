# Hacking Viber Messenger with 0day Vulnerabilities: Sniffing and DoS

 ---
Viber is a widely adopted mobile messaging application with over 500 million installations.

Nevertheless, no comprehensive digital forensic analysis has been performed with regards to it.

In this work, we describe how to:

a) decrypt Viber signaling protocol

b) deanonimize members of Viber communities

c) read deleted group messages

d) delete any Viber account with 0day vulnerability


We explain the methods and tools used to decrypt the traffic as well as thoroughly elaborate on our findings with respect to the Viber signaling messages. Furthermore, we also provide the community with a tool that helps in the visualization of the Viber protocol messages.


REFERENCES:

1. https://www.viber.com/app/uploads/Viber-Encryption-Overview.pdf

10. Wireshark protocol analyzer: https://www.wireshark.org/

11. Mitmproxy HTTPS sniffer: https://mitmproxy.org

20. Hacking Cable Modem. DerEngel. No Starch Press.

21. https://media.ccc.de/v/32c3-7133-beyond_your_cable_modem

22. https://hacker-gadgets.com/product/throwing-star-lan-tap/

30. Pro Android 4. Satya Komatineni, Dave MacLean. Apress.

31. Nox Android emulator: https://www.bignox.com/

32. JADX decompiler: https://github.com/skylot/jadx

40. PEiD and Krypto Analyzer (KANAL): https://www.peid.info

41. https://botan.randombit.net/

50. GDB debugger for Android: https://gnutoolchains.com/android/

51. GDB Documentation: http://www.gnu.org/software/gdb/documentation/

52. Perl language: https://www.perl.org/

60. Chris Eagle - The IDA Pro book. The unofficial guide to the world's most popular disassembler. No Starch Press (2011).

61. IDA - The Interactive Disassembler by Ilfak Guilfanov: https://www.hex-rays.com/

70. Python language: https://www.python.org/

71. Learning Python. Mark Lutz. O'Reilly.

80. The C Programming language. Brian W. Kernighan, Dennis M. Ritchie.

81. The C++ Programming language. Bjarne Stroustrup. AT&T Labs.

90. Fake phone numbers: https://onlinesim.ru

91. CVE-2019-18800 vulnerability by Samarkand: https://nvd.nist.gov/vuln/detail/CVE-2019-18800

92. Hashcat password cracker: https://github.com/hashcat/hashcat

93. https://www.viber.com/en/blog/2019-11-04/communities-vs-group-chats-whats-best-for-you/

94. https://www.viber.com/en/blog/2019-02-17/spark-safer-conversations-with-hidden-number-chats/

95. Michael Howard, David LeBlank. Writing Secure Code. Microsoft Press.

96. https://github.com/mitmproxy/mitmproxy/blob/master/examples/contrib/sslstrip.py

 ---
**Tags**:
#mobile #vulnerability #phone #tools #application #password #0day 
 **Speakers**:
[[Samarkand]]
