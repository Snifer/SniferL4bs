# Hack the hackers: Leaking data over SSL/TLS 

 ---
Have you considered that in certain situations the way hackers exploit vulnerabilities over the network can be predictable? Anyone with access to encrypted traffic can reverse the logic behind the exploit and thus obtain the same data as the exploit.

Various automated tools have been analyzed and it has been found that these tools operate in an unsafe way. Various exploit databases were analyzed and we learned that some of these are written in an insecure (predictable) way.

This presentation will showcase the results of the research, including examples of exploits that once executed can be harmful. The data we obtain after exploitation can be accessible to other entities without the need of decrypting the traffic. The SSL/TLS specs will not change. There is a clear reason for that and in this presentation I will argue this, but what will change for sure is the way hackers will write some of the exploits.

 ---
**Tags**:
#network #exploit #databases #tools #vulnerabilities 
 **Speakers**:
[[Ionut Cernica]]
