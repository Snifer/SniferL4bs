# A Look Inside Security At The New York Times Or A Media Security Primer For Hackers

 ---
This talk will cover the unique threats and challenges of working in information security for a news organization. Some best practices for journalists, hard technical problems facing media security, and how hackers can get involved. This talk is  for both hackers and journalists.

 ---
**Tags**:
#threats 
 **Speakers**:
[[Jesse "Agent X" Krembs]]
