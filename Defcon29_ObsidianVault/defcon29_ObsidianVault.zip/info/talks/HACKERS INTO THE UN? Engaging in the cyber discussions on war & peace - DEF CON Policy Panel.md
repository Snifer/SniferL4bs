# HACKERS INTO THE UN? Engaging in the cyber discussions on war & peace - DEF CON Policy Panel

 ---
As if 2020 and 2021 were not bad enough, the Covid-19 pandemic seemed to have been accompanied by a new rash of bad cyber- attacks on major platforms like Solarwinds and Microsoft, infrastructures worldwide subverted in ransomware campaigns, and even the very organizations researching and fighting the pandemic have been hit. 
Meanwhile, the hard work of cyber diplomacy continues, with talks on war and peace in the United Nations reaching a new stage as two working groups presented their final report and a third one is in the process of being born. Mostly the topics are on establishing norms on cyber behavior, rules of the road of what states can do in cyberspace.  But where are the hackers in all this? The Internet is famously not run by intergovernmental organizations, so the companies, civil society groups and others should somehow be involved – and one of the UN processes did in fact make a small step in that direction. But the staid ways of pin-striped cyber are hard to change. What is the best way for the community to engage?

 ---
**Tags**:
#attacks #ransomware #process 
 **Speakers**:
[[Alexander Klimburg]]
[[Chris Painter]]
[[Lauren Zabierek]]
[[Van Horenbeeck]]
[[Sheetal Kumar]]
[[Bill "Woody" Woodcock]]
