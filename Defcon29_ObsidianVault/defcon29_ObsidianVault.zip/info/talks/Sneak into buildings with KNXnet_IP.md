# Sneak into buildings with KNXnet/IP

 ---
Building Management Systems control a myriad of devices such as lighting, shutters and HVAC. KNX (and by extension KNXnet/IP) is a common protocol used to interact with these BMS. However, the public's understanding and awareness is lacking, and effective tooling is scarce all while the BMS device market keeps on growing.

The ability to craft arbitrary KNXnet/IP frames to interact with these often-insecure BMS provides an excellent opportunity in uncovering vulnerabilities in both the implementation of KNX as well as the protocol itself. From unpacking KNX at a lower level, to using a Python-based protocol crafting framework we developed to interact with KNXnet/IP implementations, in this talk we’ll go on a journey of discovering how BMS that implement KNXnet/IP work as well as how to interact with and fuzz them.

After this talk you could also claim that “the pool on the roof has a leak”!

REFERENCES:

 KNX Standard v2.1
https://my.knx.org/fr/shop/knx-specifications?product_type=knx-specifications


Scapy
https://github.com/secdev/scapy

 KNXmap
https://github.com/takeshixx/knxmap

 Papers & talks:

in)security in building automation how to create dark buildings with light speed
Thomas Brandstetter and Kerstin Reisinger
Presented at BlackHat USA 2017

https://www.blackhat.com/docs/us-17/wednesday/us-17-Brandstetter-insecurity-In-Building-Automation-How-To-Create-Dark-Buildings-With-Light-Speed-wp.pdf

 

Hacking Intelligent Building - Pwning KNX & ZigBee Networks
HuiYu Wu and YuXiang Li (Tencent)
Presented at HITB Amsterdam 2018

https://conference.hitb.org/hitbsecconf2018ams/materials/D1T2%20-%20YuXiang%20Li,%20HuiYu%20Wu%20&%20Yong%20Yang%20-%20Hacking%20Intelligent%20Buildings%20-%20Pwning%20KNX%20&%20ZigBee%20Networks.pdf

 
Security in KNX or how to steal a skyscraper
Egor Litvinov
Presented at Zero Nights 2015
http://2015.zeronights.org/assets/files/20-Litvinov.pdf

 

HVACking: Understanding the Delta Between Security and Reality
Douglas McKee and Mark Bereza
Presented at Defcon 27, 2019
https://www.mcafee.com/blogs/other-blogs/mcafee-labs/hvacking-understanding-the-delta-between-security-and-reality/

 
Anomaly Detection in BACnet/IP managed Building Automation Systems
Matthew Peacock – 2019
https://ro.ecu.edu.au/cgi/viewcontent.cgi?article=3180&context=theses

 ---
**Tags**:
#automation #awareness #vulnerabilities 
 **Speakers**:
[[Claire Vacherot]]
