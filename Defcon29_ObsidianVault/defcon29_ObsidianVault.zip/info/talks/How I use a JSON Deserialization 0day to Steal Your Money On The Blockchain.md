# How I use a JSON Deserialization 0day to Steal Your Money On The Blockchain

 ---
Fastjson is a widely used open source JSON parser with 23'100 stars on GitHub. As a basic module of countless java web services, it serves hundreds of millions of users. We managed to find a way to bypass many security checks and mitigations by using the inheritance process of some basic classes, and achieve remote code execution successfully. We will disclose these high-risk and universal gadgets for the first time in this talk.

Now, we can control many important websites and affect millions of users. Let's make things more interesting. We found that this fastjson vulnerability affect a multi-billion-dollar blockchain. We designed multiple complex gadgets based on the features of the blockchain, and exquisitely achieved information leakage and pointer hijacking. Putting all these gadgets together, we achieved remote code execution on the blockchain nodes.

However, generally after remote code execution, we seem to have no better exploit method other than the 51% attack, which will lead to serious accounting confusion. After a detailed analysis of the architecture design of the public blockchain, we found a way from RCE to steal the public blockchain users' assets almost without any notification.

To the best of our knowledge, this is the first published attack case on the realization of covertly stealing user assets after RCE on the public blockchain nodes. We will propose a more covert post penetration exploit method for public blockchain nodes in this talk.

Blockchain is not bulletproof to security vulnerability. We will show you how to use classical web vulnerabilities attack the blockchain and how to steal real money from the decentralized cyber world.

REFERENCES:

    1. https://github.com/threedr3am/gadgetinspector
    2. https://github.com/JackOfMostTrades/gadgetinspector
    3. http://i.blackhat.com/us-18/Thu-August-9/us-18-Haken-Automated-Discovery-of-Deserialization-Gadget-Chains.pdf
    4. http://i.blackhat.com/eu-19/Thursday/eu-19-Zhang-New-Exploit-Technique-In-Java-Deserialization-Attack.pdf
    5. https://asm.ow2.io/asm4-guide.pdf

 ---
**Tags**:
#exploit #vulnerability #java #websites #web #architecture #process #time #blockchain #money #vulnerabilities #0day 
 **Speakers**:
[[Hao Xing]]
[[Zekai Wu]]
