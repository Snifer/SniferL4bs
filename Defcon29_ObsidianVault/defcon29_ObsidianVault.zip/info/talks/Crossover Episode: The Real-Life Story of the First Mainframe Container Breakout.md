# Crossover Episode: The Real-Life Story of the First Mainframe Container Breakout

 ---
You've seen talks about container hacking. You've seen talks about mainframe hacking. But how often do you see them together? IBM decided to put containers on a mainframe, so a container hacker and a mainframe hacker decided to join forces and hack it. We became the first people on the planet to escape a container on a mainframe, and we’re going to show you how.

Containers on a mainframe? For real. IBM zCX is a Docker environment running on a custom Linux hypervisor built atop z/OS - IBM’s mainframe operating system. Building this platform introduces mainframe environments to a new generation of cloud-native developers-and introduces new attack surfaces that weren’t there before.

In this crossover episode, we’re going to talk about how two people with two very particular sets of skills went about breaking zCX in both directions, escaping containers into the mainframe host and spilling the secrets of the container implementation from the mainframe side.

When two very different technologies get combined for the first time, the result is new shells nobody’s ever popped before.

REFERENCES:

Getting started with z/OS Container Extensions and Docker: https://www.redbooks.ibm.com/abstracts/sg248457.html

The Path Less Traveled: Abusing Kubernetes Defaults: https://www.youtube.com/watch?v=HmoVSmTIOxM

Attacking and Defending Kubernetes Clusters: A Guided Tour: https://securekubernetes.com

Evil Mainframe penetration testing course :https://www.evilmainframe.com/

z/OS Unix System Services (USS): https://www.ibm.com/docs/en/zos/2.1.0?topic=system-basics-zos-unix-file

z/OS Concepts: https://www.ibm.com/docs/en/zos-basic-skills?topic=zc-zos-operating-system-providing-virtual-environments-since-1960s

Docker overview: https://docs.docker.com/get-started/overview/

 ---
**Tags**:
#container #escape #testing 
 **Speakers**:
[[Ian Coldwater]]
[[Chad Rikansrud (Bigendian Smalls)]]
