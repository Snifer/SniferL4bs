# No Key? No PIN? No Combo? No Problem! P0wning ATMs For Fun and Profit

 ---
Since the late great Barnaby Jack gave us “Jack Potting” in the late 2000s, there have been several talks on ATM network attacks, USB port attacks, and digital locks attacks which apply to several brands of ATM safes. In this session, I’ll discuss and demonstrate how most of these known attack vectors have been remediated, while several fairly simple attacks against the machine and the safe still remain. We’ll dive into how ATMs work, the steps I went through to become a “licenced ATM operator” which enabled my research, and how I identified the vulnerabilities. I’ll show how, with very little technical expertise and 20 minutes, these attacks lead directly past “secure” and allow attackers to collect a lot more than $200.

REFERENCES
Barnaby Jack - “Jackpotting Automated Teller Machines” - (2010) 
from DEFCON - https://www.youtube.com/watch?v=FkteGFfvwJ0 


Weston Hecker - “Hacking Next-Gen ATM's From Capture to Cashout” - (2016) 
from DEFCON - https://www.youtube.com/watch?v=1iPAzBcMmqA 


Trey Keown and Brenda So - “Applied Cash Eviction through ATM Exploitation” (2020) 
        from DEFCON - https://www.youtube.com/watch?v=dJNLBfPo2V8 


Triton - “Terminal Communications Protocol And Message Format Specification” (2004) 
from Complete ATM Services - tinyurl.com/7nf2fdy5


Rocket ATM - “Hyosung ATM Setup Part 1 - Step by Step” (2018) 
        from Rocket ATM - https://www.youtube.com/watch?v=abylmrBkOGM&t=3s 


Rocket ATM - “Hyosung ATM Setup Part 2 - Step by Step” (2018) 
        from Rocket ATM -  https://www.youtube.com/watch?v=IM9ZG46fwL8 


Hyosung - “NH2600 Service Manual v1.0” (2013) 
        From Prineta - https://tinyurl.com/c6jd4hd9 


Hyosung - “NH2700 Operator Manual v1.2” (2010) 
        From AtmEquipment.com - https://tinyurl.com/rp2cad8 


 ---
**Tags**:
#network #attacks #locks 
 **Speakers**:
[[Roy Davis]]
