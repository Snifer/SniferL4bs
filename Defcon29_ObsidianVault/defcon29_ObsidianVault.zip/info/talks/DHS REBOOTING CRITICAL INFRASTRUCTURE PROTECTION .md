# DHS REBOOTING CRITICAL INFRASTRUCTURE PROTECTION 

 ---
In 1998 the US government issued the first major policy document on Critical Infrastructure Protection (CIP). Since then, CIP has become one of the most fundamental tasks for governments everywhere, and has given birth to a plethora of institutions and processes seeking to manage what is called a “Public Private Partnership” between government, industry, and civil society. But despite all the efforts put into information exchanges, incident management, but also supply chain protection and even national industrial policies, cyber-attacks have not decreased, both in the United States and elsewhere. What else needs to be done? What lessons learned are there from international experiences? And how can the community help best?


 ---
**Tags**:
#protection #government #international #policy 
 **Speakers**:
[[Lily Newman]]
[[Alexander Klimburg]]
[[Faye Francy]]
[[Eric Goldstein]]
[[Amelie Koran]]
[[Danny McPherson]]
