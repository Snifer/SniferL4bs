# Defending against nation-state (legal) attack: how to build a privacy-protecting service in the era of ubiquitous surveillance

 ---
US diplomacy and the US District Court of Northern California provide a nearly impenetrable shield against legal assault from other countries for the many tech companies that choose the San Francisco Bay Area as their legal domicile. But US domicile has left companies undefended against ECPA, CALEA, Patriot Act and FISA requests and the gag orders which prevent their disclosure, and the US has little or no statutory protections for users’ privacy. So how do you hack the international legal and diplomatic system to defend the privacy of users of Internet services against nation-state legal attacks?  The privacy-and-security-oriented non-profit DNS recursive resolver Quad9 spent four years working the system and learning from prior examples like ProtonMail, and Bill Woodcock, the chair of Quad9’s Foundation Council, will talk about the threat model Quad9 is defending against, how legal domicile and physical presence interact, and how Quad9 is building a model that other privacy-respecting services can follow. He’ll discuss the critical differences between jurisdictions and legal regimes that Quad9 uncovered in their four-year selection process, and the key and differentiating protections the Swiss government offers that the US and EU governments do not. And if y’all get tired of that, you might be able to convince him to talk about the injunction Sony Music got against Quad9 in the copyright-troll court in Hamburg and why more privacy may also come at the risk of more censorship.

 ---
**Tags**:
#privacy #physical #legal #key #government #risk #international 
 **Speakers**:
[[Bill "Woody" Woodcock]]
