# Glitching RISC-V chips: MTVEC corruption for hardening ISA

 ---
RISC-V is an open standard instruction set architecture (ISA) provided under open-source licenses that do not require fees to use. ISA is based on established reduced instruction set computer (RISC) principles. RISC-V has features to increase computer speed, while reducing cost and power use.

Many industry players like Google, IBM, NVIDIA, Qualcomm, and Samsung are members of the RISC-V Foundation and have long supported RISC-V development. In 2016, NVIDIA unveiled plans to replace the internal microcontrollers of their graphic cards with next-gen RISC-V-based controllers built for upcoming NVIDIA GPUs.

NVIDIA's Product Security undertook a detailed architectural analysis and research of the RISC-V IP, discovering a potential risk with the ambiguous specification of the Machine Trap Base Address (MTVEC) register. This ambiguity leads to potential fault injection vulnerabilities under physical attack models.

 ---
**Tags**:
#injection #physical #hardening #research #risk #architecture #vulnerabilities 
 **Speakers**:
[[Adam 'pi3' Zabrocki]]
[[Alex Matrosov]]
