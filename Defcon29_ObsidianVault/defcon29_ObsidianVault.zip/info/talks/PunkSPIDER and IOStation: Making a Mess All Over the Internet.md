# PunkSPIDER and IOStation: Making a Mess All Over the Internet

 ---
We've been getting asked a lot for "that tool that was like Shodan but for web app vulns.” In particular WTF happened to it? Punkspider (formerly known as PunkSPIDER but renamed because none of us could remember where tf the 
capital letters go) was taken down a couple of years ago due to multiple ToS issues and threats. It was originally funded by DARPA.  We weren’t sure in which direction to keep expanding, and it ended up being a nightmare to 
sustain. We got banned more than a 15 year old with a fake ID trying to get into a bar. It became a pain and hardly sustainable without a lot of investment in time and money. Each time we got banned it meant thousands of dollars 
and countless hours moving sh** around.

Now we’ve solved our problems and completely re-engineered/expanded the system. It is not only far more efficient with real-time distributed computing and checks for way more vulns, we had to take some creative ways through the 
woods – this presentation covers both the tool itself and the story of the path we had to take to get where it is, spoiler alert: it involves creating our own ISP and data center in Canada and integrating freely available data 
that anyone can get but most don’t know is available. Come play with us and see what the wild west of the web looks like and listen to our story, it’s fun and full of angry web developers. We’ll also be releasing at least 10s 
of thousands of vulnerabilities and will be taking suggestions from the audience on what to search. Fun vulns found get a t-shirt, super fun ones get a hoodie thrown at them.


REFERENCES:

https://www.youtube.com/watch?v=AbS_EGzkNgI (Shmoo 2013 talk)
https://hadoop.apache.org/
https://aws.amazon.com/kubernetes/
https://www.docker.com/
https://www.python.org/
https://www.apache.org/licenses/LICENSE-2.0
https://kafka.apache.org/
https://owasp.org/www-project-top-ten/

 ---
**Tags**:
#web #time #vulnerabilities 
 **Speakers**:
[[_hyp3ri0n aka Alejandro Caceres]]
[[Jason Hopper]]
