# 
Making the DEF CON 29 Badge

 ---
Come meet the new badge makers and hear the story of how this year's badge was created amidst a global pandemic. We'll share tales of chip shortages, delayed parts, and late nights, as well as discuss how the badge works and what you can do with it. Maybe even some hints about the challenges within...

 ---
**Tags**:

 **Speakers**:
[[Michael Whiteley]]
[[Katie Whiteley]]
