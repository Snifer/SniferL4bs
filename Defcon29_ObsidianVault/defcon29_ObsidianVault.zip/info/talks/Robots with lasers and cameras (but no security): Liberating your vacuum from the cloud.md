# Robots with lasers and cameras (but no security): Liberating your vacuum from the cloud

 ---
Vacuum robots are becoming increasingly popular and affordable as their technology grows ever more advanced, including sensors like lasers and cameras. It is easy to imagine interesting new projects to exploit these capabilities. However, all of them rely on sending data to the cloud. Do you trust the companies promise that no video streams are uploaded to the cloud and that your personal data is safe? Why not collect the dust with open-source software?

I previously showed ways to root robots such as Roborock and Xiaomi, which enabled owners to use their devices safely with open-source home automation. In response, vendors began locking down  their devices with technologies like Secure Boot, SELinux, LUKS encrypted partitions and custom crypto that prevents gaining control over our own devices. This talk will update my newest methods for rooting these devices.

The market of vacuum robots expanded in the past 2 years. In particular, the Dreame company has recently released many models with interesting hardware, like ToF cameras and line lasers. This can be a nice alternative for rooting. I will show easy ways to get root access on these devices and bypass all security. I will also discuss backdoors and security issues I discovered from analysis.  You will be surprised what the developers left in the firmware.

REFERENCES:
Unleash your smart-home devices: Vacuum Cleaning Robot Hacking (34C3)
https://dontvacuum.me/talks/34c3-2017/34c3.html

Having fun with IoT: Reverse Engineering and Hacking of Xiaomi IoT Devices
https://dontvacuum.me/talks/DEFCON26/DEFCON26-Having_fun_with_IoT-Xiaomi.html

https://linux-sunxi.org/Main_Page

 ---
**Tags**:
#exploit #trust #root #video #crypto #cloud 
 **Speakers**:
[[Dennis Giese]]
