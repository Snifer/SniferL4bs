# eBPF, I thought we were friends ! 

 ---
Since its first appearance in Kernel 3.18, eBPF (Extended Berkley Packet Filter) has progressively become a key technology for observability in the Linux kernel. Initially dedicated to network monitoring, eBPF can now be used to monitor and trace any kind of kernel space activity.

Over the past few years, many vendors have started using eBPF to speed up their services or introduce innovative features. Cilium, Calico, Cloudflare, Netflix and Facebook are leading the charge, showing off new complex networking use cases on a monthly basis. On the security side of things, Google recently contributed the Kernel Runtime Security Instrumentation which opens the door to writing Linux Security Modules with eBPF.

In other words, eBPF is the new kid in town and a growing number of companies are running services with eBPF access in production. This leads us to a simple question: how bad can things get if one of those services were to be compromised ? This talk will cover how we leveraged eBPF to implement a full blown rootkit with all the features you would expect: various obfuscation techniques, command and control with remote and persistent access, data theft and exfiltration techniques, Runtime Application Self-Protection evasion techniques, and finally two original container breakout techniques.

Simply put, our goal is to demonstrate that rogue kernel modules might have finally found a worthy opponent. We will also detail how to detect such attacks and protect your infrastructure from them, while safely enjoying the exciting capabilities that eBPF has to offer.

REFERENCES:
Bibliography and documentation links cited in the submission:

1. Russian GRU 85th GTsSS deploys previously undisclosed drovorub malware, NSA / FBI, August 2020 https://media.defense.gov/2020/Aug/13/2002476465/-1/-1/0/CSA_DROVORUB_RUSSIAN_GRU_MALWARE_AUG_2020.PDF
2. Kprobe-based Event Tracing, https://www.kernel.org/doc/html/latest/trace/kprobetrace.html
3. Linux Kernel tracepoints, https://www.kernel.org/doc/html/latest/trace/tracepoints.html
4. “bpf_probe_write_user” bpf helper, https://elixir.bootlin.com/linux/v5.11.11/source/include/uapi/linux/bpf.h#L1472
5. Uprobe-based Event Tracing, https://www.kernel.org/doc/html/latest/trace/uprobetracer.html
6. Cilium’s XDP documentation, https://docs.cilium.io/en/latest/bpf/#xdp

Previous eBPF related talks & projects that helped us build the rootkit:

7. Evil eBPF In-Depth: Practical Abuses of an In-Kernel Bytecode Runtime, Jeff Dileo, DEF CON 27, https://www.defcon.org/html/defcon-27/dc-27-speakers.html#Dileo
8. Process level network security monitoring and enforcement with eBPF, Guillaume Fournier, https://www.sstic.org/2020/presentation/process_level_network_security_monitoring_and_enforcement_with_ebpf/
9. Runtime Security with eBPF, Sylvain Afchain, Sylvain Baubeau, Guillaume Fournier, https://www.sstic.org/2021/presentation/runtime_security_with_ebpf/
10. Monitoring and protecting SSH sessions with eBPF, Guillaume Fournier, https://www.sstic.org/2021/presentation/monitoring_and_protecting_ssh_sessions_with_ebpf/

 ---
**Tags**:
#network #attacks #monitoring #key #obfuscation #kernel #container #capabilities #documentation #exfiltration 
 **Speakers**:
[[Guillaume Fournier]]
[[Sylvain Afchain]]
[[Sylvain Baubeau]]
