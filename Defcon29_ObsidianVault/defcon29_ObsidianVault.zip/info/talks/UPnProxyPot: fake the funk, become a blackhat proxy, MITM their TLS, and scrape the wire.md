# UPnProxyPot: fake the funk, become a blackhat proxy, MITM their TLS, and scrape the wire

 ---
UPnP sucks, everybody knows it, especially blackhat proxy operators.  UPnProxyPot was developed to MITM these operators to see what they're doing with their IoT proxy networks and campaigns.  We'll cover SSDP, UPnP, UPnProxy research/campaigns as well as cover a new Golang based honeypot, so we can all snoop on them together!

REFERENCES:
http://www.upnp-hacks.org (OG disclosure)
https://www.youtube.com/watch?v=FU6qX0-GHRU (DEF CON 19 talk I attended)
https://www.akamai.com/us/en/multimedia/documents/white-paper/upnproxy-blackhat-proxies-via-nat-injections-white-paper.pdf (my initial UPnProxy research)
https://blogs.akamai.com/sitr/2018/11/upnproxy-eternalsilence.html (additional UPnProxy campaign researcher, also mine)



 ---
**Tags**:
#proxy 
 **Speakers**:
[[Chad Seaman]]
