# Do you like to read? I know how to take over your Kindle with an e-book

 ---
Since 2007, Amazon has sold tens of millions of Kindles, which is impressive. But this also means that tens of millions of people can be hacked through a software bug in those same Kindles. Their devices can be turned into bots, their private local networks can be compromised, and perhaps even information in their billing accounts can be stolen.
 
The easiest way to remotely reach a user's Kindle is through an e-book. A malicious book can be published and made available for free access in any virtual library, including the Kindle Store, or sent directly to the end-user device via Amazon services.
While you might not be happy with the writing in a particular book, nobody expects to download one that is malicious. No such scenarios have been publicized. Antiviruses do not have signatures for e-books.
But... we succeeded in making a malicious book for you. If you open this book on a Kindle device, it causes a hidden piece of code to be executed with root rights. From this moment on, you lost your e-reader, account and more.
 
Want to know the details?

 ---
**Tags**:
#software #root #end-user #signatures 
 **Speakers**:
[[Slava Makkaveev]]
