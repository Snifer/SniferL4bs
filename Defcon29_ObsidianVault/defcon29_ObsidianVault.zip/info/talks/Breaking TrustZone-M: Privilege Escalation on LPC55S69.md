# Breaking TrustZone-M: Privilege Escalation on LPC55S69

 ---
The concept of Trusted Execution Environments has been broadly introduced to microcontrollers with ARM’s TrustZone-M. While much experience with TrustZone-A can be applied, architectural differences with ARMv8-M lead to a very different approach to configuration and transitions between secure and non-secure worlds. This talk will deep dive into how TrustZone-M works, where to look for weaknesses in implementations, and a detailed look into NXP LPC55S69’s implementation including discovering an undocumented peripheral that leads to a priviledge escalation vulnerability exploitable with TrustedFirmware-M. Finally, NXP PSIRT will be used as a case study in how _not_ to respond to a vulnerability report.

REFERENCES:
TrustZone technology for the ARMv8-M architecture Version 2.0; ARM; https://developer.arm.com/documentation/100690/0200

Your Peripheral Has Planted Malware -- An Exploit of NXP SOCs Vulnerability; Yuwei Zheng, Shaokun Cao, Yunding Jian, Mingchuang Qin; DEFCON 26; https://media.defcon.org/DEF CON 26/DEF CON 26 presentations/DEFCON-26-Yuwei-Zheng-Shaokun-Cao-Bypass-the-SecureBoot-and-etc-on-NXP-SOCs-Updated.pdf

 ---
**Tags**:
#vulnerability #configuration #architecture 
 **Speakers**:
[[Laura Abbott]]
[[Rick Altherr]]
