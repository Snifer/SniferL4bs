# Privacy Without Monopoly: Paternalism Works Well, But Fails Badly

 ---
Governments around the world (US, UK, EU) are planning to force interoperability on the biggest tech platforms. Companies like Facebook say that this is a privacy disaster because it would hurt their ability to keep us safe from privacy invasions. Yeah, I know. But even if you DO think Facebook has our best interests at heart, monopoly is a deeply stupid way protect privacy. I will present "Privacy Without Monopoly," a major EFF white paper I co-authored with Bennett Cyphers, which sets out a framework for understanding how privacy and interop aren't just compatible - they rely on one another!

https://www.eff.org/wp/interoperability-and-privacy

 ---
**Tags**:
#privacy 
 **Speakers**:
[[Cory Doctorow]]
