# D0 N0 H4RM: A Healthcare Security Conversation

 ---
Mired in the hell of a global pandemic, hospital capacity stressed to its limit, doctors and nurses overworked and exhausted... surely the baddies would cut us a little slack and leave little 'ol healthcare alone for a bit, right? Well, raise your hand if you saw this one coming. Another year of rampaging ransomware, of pwned patient care- only this time backdropped by the raging dumpster fire that is COVID. Can we once and for all dispel with the Pollyannas telling us that nobody would knowingly seek to harm patients? And if we can't convince the powers that be- whether in the hospital C-suite or in DC- that we need to take this $%& seriously now, then what hope do we have for pushing patient safety to the forefront when things return to some semblance of normal? With a heavily curated panel including policy badasses, elite hackers, and seasoned clinicians - D0 N0 H4RM remains the preeminent forum where insight from experts collide with the ingenuity and imagination of the DEF CON grassroots to inspire activism and collaboration stretching far beyond closing ceremonies. 

Moderated by physician hackers quaddi and r3plicant, this perennially packed event always fills up fast - so make sure you join us. As always- the most important voice is yours.

 ---
**Tags**:
#time #healthcare #policy 
 **Speakers**:
[[Christian “quaddi” Dameff MD]]
[[Jeff “r3plicant” Tully MD]]
[[Jessica Wilkerson]]
[[Josh Corman]]
[[Gabrielle Hempel]]
[[Stephanie Domas]]
