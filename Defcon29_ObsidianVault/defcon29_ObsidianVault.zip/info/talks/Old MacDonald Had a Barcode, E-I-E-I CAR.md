# Old MacDonald Had a Barcode, E-I-E-I CAR

 ---
For decades, the EICAR test string has been used by antivirus and security vendors to safely test their detection engines without having to use live virulent samples which could cause harm. What would happen if you took that string, encoded it into a machine readable format like a QR code and started scanning various devices with the QR code? This talk shows how there are a lot of systems out there that aren't expecting an input string like EICAR and how many of them just collapse when shown the code. We will also discuss the types of systems you can target and how you may be able to extend this to more than a nuisance attack.

REFERENCES:


EICAR test string: https://www.eicar.org/?page_id=3950
EICAR wikipedia entry: https://en.wikipedia.org/wiki/EICAR_test_file
QR codes: https://en.wikipedia.org/wiki/QR_code
Risks surrounding QR codes: https://en.wikipedia.org/wiki/QR_code#Risks


 ---
**Tags**:
#antivirus #detection #string 
 **Speakers**:
[[Richard Henderson]]
