# Wibbly Wobbly, Timey Wimey – What's Really Inside Apple's U1 Chip

 ---
Apple introduced an Ultra Wideband (UWB) chip in the iPhone 11. Its cryptographically secured spatial measurement capabilities are accessible via the Nearby Interaction framework since iOS 14. As of now, it only supports interaction with other Apple devices including the latest Apple Watch and HomePod mini. These are the first steps to support UWB in a larger ecosystem, as measuring precise distance and direction can be an enabler for various future applications. The automotive industry already announced UWB support for mobile car keys on the iPhone.

But what’s really inside Apple’s U1 chip, internally called Rose? In this talk, we will travel through time, space, firmware and kernel components—and fight daemons to modify firmware interaction from user space. This will not only cover one or two, but three firmwares that process or forward each Rose time measurement: The Rose Digital Signal Processor (DSP), Rose Application Processor (AP), and the Always-On Processor (AOP).

REFERENCES:

There's almost nothing known about UWB on the iPhones... So the only reference is this:
https://support.apple.com/guide/security/ultra-wideband-security-sec1e6108efd/web

 ---
**Tags**:
#mobile #firmware #kernel #process #time #capabilities 
 **Speakers**:
[[jiska]]
[[Alexander Heinrich]]
