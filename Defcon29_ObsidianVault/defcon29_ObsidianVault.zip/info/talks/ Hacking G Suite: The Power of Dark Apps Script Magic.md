#  Hacking G Suite: The Power of Dark Apps Script Magic

 ---
You’ve seen plenty of talks on exploiting, escalating, and exfiltrating the magical world of Google Cloud (GCP), but what about its buttoned-down sibling? This talk delves into the dark art of utilizing Apps Script to exploit G Suite (AKA Google Workspace).

As a studious sorcerer, you’ll discover how to pierce even the most fortified G Suite enterprises. You’ll learn to conjure Apps Script payloads to bypass powerful protective enchantments such as U2F, OAuth app allowlisting, and locked-down enterprise Chromebooks.

Our incantations don’t stop at the perimeter, we will also discover novel spells to escalate our internal privileges and bring more G Suite accounts under our control. Once we’ve obtained the access we seek, we’ll learn various curses to persist ourselves whilst keeping a low profile so as to not risk an unwelcome exorcism.

You don’t need divination to see that this knowledge just might rival alchemy in value.

REFERENCES:
No real academic references, this is all original research gleaned from real-world testing and reading documentation.

 ---
**Tags**:
#exploit #research #risk #testing 
 **Speakers**:
[[Matthew Bryant]]
