# A new class of DNS vulnerabilities affecting many DNS-as-Service platforms

 ---
We present a novel class of DNS vulnerabilities that affects multiple DNS-as-a-Service (DNSaaS) providers. The vulnerabilities have been proven and successfully exploited on three major cloud providers including AWS Route 53 and may affect many others. Successful exploitation of the vulnerabilities may allow exfiltration of sensitive information from service customers' corporate networks. The leaked information contains internal and external IP addresses, computer names, and sometimes NTLM hashes. The number of organizations vulnerable to this weakness is shocking. Over a few hours of DNS sniffing, we received sensitive information carried by DNS update queries from ~1M Windows endpoints from around 15,000 potentially vulnerable companies, including 15 Fortune 500 companies. In some organizations, there were more than 20,000 endpoints that actively leaked their information out of the organization. We will review possible mitigations to this problem and solutions for both DNSaaS providers and managed networks.



REFERENCES:

I. Microsoft Windows DNS Update algorithm explained -        

        https://docs.microsoft.com/en-us/troubleshoot/windows-server/networking/configure-dns-dynamic-updates-windows-server-2003

   
II. An excellent blog post by Matthew Bryant on hijacking DNS Updates abusing a dangling domain issue on Guatemala State's Top Level Domain -

        https://thehackerblog.com/hacking-guatemalas-dns-spying-on-active-directory-users-by-exploiting-a-tld-misconfiguration/

 ---
**Tags**:
#algorithm #domain #exfiltration #vulnerabilities #cloud 
 **Speakers**:
[[Shir Tamari]]
[[Ami Luttwak]]
