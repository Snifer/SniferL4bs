# Ransomware’s Big Year – from nuisance to “scourge”? - DEF CON Policy Panel

 ---
According to a former senior White House official, 2020 was the year that ransomware went from being a nuisance to a full-scale national security threat and a “scourge”. After an awkward adolescence spent shaking down individual users for a couple hundred dollars and a big debut in 2017 with WannaCry and NotPetya , ransomware really hit the big time in 2020. Ransom payments may have topped $400 million plus that year. But those sums are nothing compared to the damage that ransomware campaigns can cause, especially when they hit critical infrastructure like Colonial Pipeline. And even months after Colonial Pipeline, ransomware continues to regularly subvert and cripple enterprises in the US and Europe. Are we not learning the right lessons on defense? Or is it not just an infosec problem, but also an international security issue, with cybercrime being actively wielded – yet again – as a political weapon?


 ---
**Tags**:
#ransomware #time #international 
 **Speakers**:
[[Jen Easterly]]
[[Chris Painter]]
[[Kurtis Minder]]
[[Jane Holl Lute]]
[[Ellen Nakashima]]
