# Rotten code, aging standards, & pwning IPv4 parsing across nearly every mainstream programming language

 ---
Openness to responsibly disclosed external vulnerability research is crucial for modern software maintainers and security teams. Changes in upstream dependency code may have pulled the safety rug out from underneath widely trusted core libraries, leaving millions of services vulnerable to unsophisticated attacks. The impact of even a single reasonably well-distributed supply-chain security vulnerability will be felt by engineering teams across many applications, companies, and industries.

We'd like to discuss an IP address parsing vulnerability first discovered in private-ip, a small and infrequently maintained yet critically important NodeJS package for determining if an IP address should be considered part of a private range or not. We'll talk about not only the implications of this CVE but taking the main idea and applying it across multiple programming languages in uniquely disturbing ways.

Sometimes, the effects of code rot are even more far-reaching than we could possibly expect, and if you pull on a thread, it just keeps going. Sometimes, you get lucky when you know exactly what you're looking for. Sometimes, it's hard to convince other technically-minded folks that a seemingly trivial implementation flaw is dangerous in capable hands.

This talk is beginner as well as advanced-friendly; we'll show you the basics a hacker or a programmer needs to know about IP address parsing and how to tell your octal from your decimal along the way.

REFERENCES:

Researchers involved in this work:
- Victor Viale: https://github.com/koroeskohr, koroeskohr
- Sick Codes: https://github.com/sickcodes, sickcodes
- Kelly Kaoudis: https://github.com/kaoudis, kaoudis
- John Jackson: https://www.johnjhacking
- Nick Sahler: https://github.com/nicksahler, tensor_bodega
- Cheng Xu: https://github.com/xu-cheng

Selected press coverage (as of May '21)
- https://www.bleepingcomputer.com/news/security/critical-netmask-networking-bug-impacts-thousands-of-applications/
- https://www.theregister.com/2021/03/29/netmask_cve/
- https://www.bleepingcomputer.com/news/security/python-also-impacted-by-critical-ip-address-validation-vulnerability/

Currently released advisories related to this work (as of May '21)
- https://sick.codes/sick-2021-011/
- https://vuln.ryotak.me/advisories/6
- https://sick.codes/sick-2021-018/
- https://sick.codes/sick-2020-022/

Additional
- https://sick.codes/universal-netmask-npm-package-used-by-270000-projects-vulnerable-to-octal-input-data-server-side-request-forgery-remote-file-inclusion-local-file-inclusion-and-more-cve-2021-28918/
- https://blog.urth.org/2021/03/29/security-issues-in-perl-ip-address-distros/
- https://blog.dave.tf/post/ip-addr-parsing/
- https://security-tracker.debian.org/tracker/CVE-2021-29424
- https://security-tracker.debian.org/tracker/CVE-2021-29662
- https://www.npmjs.com/package/netmask
- https://github.com/rs/node-netmask
- https://bugs.python.org/issue36384#msg392423
- https://github.com/rust-lang/rust/pull/83652
- https://github.com/rust-lang/rust/issues/83648

 ---
**Tags**:
#vulnerability #software #programming #research #impact 
 **Speakers**:
[[Kelly Kaoudis]]
[[Sick Codes]]
