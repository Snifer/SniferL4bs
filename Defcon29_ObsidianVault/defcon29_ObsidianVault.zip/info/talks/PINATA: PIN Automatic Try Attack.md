# PINATA: PIN Automatic Try Attack

 ---
A brute force attack is a trial-and-error method used to obtain information such as user passwords or personal identification numbers (PINs). This attack methodology should be impossible to apply to the actual secured EMV bank cards. In this talk, we will analyze how an inadequate implementation could rely on an extreme and sophisticated PIN brute force attack against 10,000 combinations from 4 digit PIN that could affect millions of contact EMV cards. 

 ---
**Tags**:
#passwords #identification 
 **Speakers**:
[[Salvador Mendoza]]
