# MAVSH> Attacking from Above

 ---
Over the course of 2020 and 2021, drone enthusiasts and the FAA have been locked in a series of legal battles over the future of unmanned aviation.

New regulations and restrictions, such as Remote Identification, aim to leave drone and model aviation hobbyists with a grim choice: incur countless financial costs, or lose the ability to fly freely.

Not only do these regulations impact hobbyists, they also restrict our ability to use drones as recon and payload delivery tools, but the FAA gave us a loophole.

In this talk, I'll share my knowledge of the MAVLink protocol and how it can be modified to take advantage of that loophole. I'll also show you how to build a drone capable of 20+ minute flights, potentially multiple miles of range, and hosting a Raspberry Pi 0 W onboard, enabling remote command execution without the use of onboard WiFi or cellular networks ALL while exploiting that loophole.

Come learn how and why the FAA "Can't Stop the Signal"!

REFERENCES
Ardupilot:
https://ardupilot.org/
https://github.com/ArduPilot/ardupilot

MAVLink:
https://mavlink.io/en/

Danger Drone and Defense Measures:
https://resources.bishopfox.com/files/slides/2017/DEF_CON_25_(2017)-Game_of_Drones-Brown_Latimer-29July2017.pdf

https://resources.bishopfox.com/resources/tools/drones-penetration-testers/attack-tools/

Watch Dogs Drone:
https://hackaday.com/2018/05/27/watch-dogs-inspired-hacking-drone-takes-flight/

FAA vs RDQ:
https://www.racedayquads.com/pages/rdq-vs-faa
https://www.gofundme.com/f/savefpv?utm_campaign=p_cp_url&utm_medium=os&utm_source=customer
https://www.suasnews.com/2021/03/racedayquads-com-vs-faa-court-case-in-defense-of-all-drone-pilots-and-model-aviators/

 ---
**Tags**:
#legal #financial #cellular #impact 
 **Speakers**:
[[Sach]]
