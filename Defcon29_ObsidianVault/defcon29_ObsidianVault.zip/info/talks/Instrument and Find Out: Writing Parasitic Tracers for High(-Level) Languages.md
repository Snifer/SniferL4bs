# Instrument and Find Out: Writing Parasitic Tracers for High(-Level) Languages

 ---
Modern programming languages are, more and more, being designed not just around performance, ease-of-use, and (sometimes) security, but also performance monitoring and introspectability. But what about the languages that never adopted such concepts from their peers? Or worse, what about the languages that tacked on half-hearted implementations as an afterthought? The answer is simple, you write your own and instrument them into the language dynamically.

In this talk, we will discuss the process for developing generalized parasitic tracers targeting specific programming languages and runtimes using Ruby as our case study. We will show how feasible it is to write external tracers targeting a language and its runtime, and discuss best practices for supporting different versions over time.

REFERENCES:

* https://github.com/ruby/ruby
* https://frida.re/docs/javascript-api/

 ---
**Tags**:
#monitoring #programming #process #performance 
 **Speakers**:
[[Jeff Dileo]]
