# Time Turner - Hacking RF Attendance Systems (To Be in Two Places at Once) 

 ---
It's a tale as old as time: a graduating senior needs two more courses to graduate, but the lectures happen to be scheduled at the same time and the school's new high-tech wireless attendance tracking system makes it impossible to attend both courses... in theory. By reverse-engineering the attendance devices and emulating them using a hidden Arduino, the system can be tricked into giving attendance credit for both courses without being physically present. It's a real-life "time turner," allowing him to be in two places at once.


REFERENCES:

https://github.com/wizard97/iSkipper/releases/download/v1.0.0/iskipper.pdf
https://courses.ece.ubc.ca/cpen442/termproject/reports/2010/iclicker.pdf
https://people.ece.cornell.edu/land/courses/ece4760/FinalProjects/f2015/cs886_kdv8/cs886_kdv8/cs886_kdv8/index.html
https://github.com/wizard97/iSkipper
https://github.com/charlescao460/iSkipper-Software

 ---
**Tags**:
#wireless #reverse-engineering #tracking #time 
 **Speakers**:
[[Vivek Nair]]
