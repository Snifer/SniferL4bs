# Defeating Physical Intrusion Detection Alarm Wires

 ---
Alarm systems are ubiquitous - no longer the realm of banks and vaults only, many people now have them in their homes or workplaces.  But how do they work?  And the logical follow-up question - how can they be hacked? 

This talk focuses on the communication lines in physical intrusion detection systems: how they are secured, and what vulnerabilities exist.  We’ll discuss the logic implemented in the controllers and protections on the communication lines including end of line resistors - and all the ways that this aspect of the system can be exploited.

In particular, we’ll release schematics for a tool we’ve developed that will enable measuring end-of-line resistor systems covertly, determining the necessary re-wiring to defeat the sensors, and deploy it without setting off the alarm. 

After the talk, you can head over to the Lock Bypass Village to try these techniques out for yourself!

 ---
**Tags**:
#physical #detection #banks #intrusion #vulnerabilities 
 **Speakers**:
[[Bill Graydon]]
