# Racketeer Toolkit. Prototyping Controlled Ransomware Operations

 ---
Offensive testing in organizations has shown a tremendous value for simulating controlled attacks.  
While cyber extortion may be one of the main high ROI end goals for the attacker, surprisingly few tools exist to simulate ransomware operations.

Racketeer is one such tool. It is an offensive agent coupled with a C2 base, built to help teams to prototype and exercise a tightly controlled ransomware campaign.

We walk through the design considerations and implementation of a ransomware implant which emulates logical steps taken to manage connectivity and asset encryption and decryption capabilities. We showcase flexible and actionable ways to prototype components of fully remote ransomware operation including key and data management, as well as data communication that is used in ransomware campaigns.

Racketeer is equipped with practical safeguards for lights out operations, and can address the goals of keeping strict control of data and key management in its deployment, including target containment policy, safe credential management, and implementing operational security in simulated operations.

Racketeer can help gain better optics into IoCs, and is helpful in providing detailed logs that can be used to study the behavior and execution artifacts of a ransomware agent.

 ---
**Tags**:
#encryption #decryption #ransomware #tools #key #testing 
 **Speakers**:
[[Dimitry "Op_Nomad" Snezhkov]]
