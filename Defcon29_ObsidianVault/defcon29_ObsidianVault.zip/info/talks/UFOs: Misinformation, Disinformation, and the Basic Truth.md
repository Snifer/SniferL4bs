# UFOs: Misinformation, Disinformation, and the Basic Truth

 ---
The talk, "UFOs and Government: A Historical Inquiry" given at Def Con 21 has been viewed thousands of times. It was a serious well-documented exploration of the UFO subject based on Thieme's participation in research into the subject with colleagues. The book of that name is the gold standard for historical research into the subject and is in 100+ university libraries.

This update was necessitated by recent UFO incidents and the diverse conversations triggered by them. Contextual understanding is needed to evaluate current reports from pilots and naval personnel, statements from senators and Pentagon personnel, and indeed, all the input from journalists who are often unfamiliar with the field and the real history of documented UFOs over the past 70 years.

Thieme was privileged to participate with scholars and lifelong researchers into the massive trove of reports. We estimate that 95% can be explained by mundane phenomena but the remainder suggest prolonged interaction with our planetary society over a long period. Thieme also knows that when you know you don't know something, don't suggest that you do. Stay with the facts, stay with the data. Sensible conclusions, when we do that, are astonishing enough.

Reality, as Philip K. Dick said, will not go away just because we refuse to believe in it.

 ---
**Tags**:
#research #historical #history 
 **Speakers**:
[[Richard Thieme AKA neuralcowboy]]
